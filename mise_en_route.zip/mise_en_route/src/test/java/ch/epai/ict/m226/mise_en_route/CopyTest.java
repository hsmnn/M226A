package ch.epai.ict.m226.mise_en_route;

import org.junit.*;

public class CopyTest {

    /**
     * La classe Copy doit avoir un constructeur avec la signature Copy(Book
     * book). La valeur du paramètre doit être affectée à l'attribut book. Si la
     * valeur du paramètre est null, la valeur de l'attribut book doit être null.
     */
    @Test
    public void constructor_setTitle_shouldCreateInstance() {
        Book a = new Book("title");
        Copy copyBookA = new Copy(a);
        Assert.assertNotNull(copyBookA);
    }

    /**
     * L'accesseur getRfid doit renvoyer la valeur de l'attribut rfid. Le mutateur
     * setRfid doit modifier la valeur de l'attribut rfid. La valeur de l'attribut
     * doit être celle du paramètre ou une chaîne vide si cette valeur est null.
     */
    @Test
    public void rfidGetterAndSetter_setValue_shouldReturnValue() {

        Book b = new Book("title");
        Copy copyBookB = new Copy(b);
        String expected;
        String actual;

        expected = "";
        actual = copyBookB.getRfid();
        Assert.assertEquals("L'accesseur getRfid doit renvoyer une chaîne vide après l'instanciation", expected,
                actual);

        expected = "1234567890";
        copyBookB.setRfid(expected);
        actual = copyBookB.getRfid();
        Assert.assertEquals(
                "Le mutateur setRfid doit modifier la valeur de l'attribut rfid et l'accesseur getRfid doit renvoyer cette valeur.",
                expected, actual);

        expected = "";
        copyBookB.setRfid(null);
        actual = copyBookB.getRfid();
        Assert.assertEquals(
                "Si la valeur du paramètre du mutateur setRfid est null, la valeur de l'attribut rfid doit être une chaîne vide.",
                expected, actual);
    }

    /**
     * L'accesseur getType doit renvoyer la valeur de l'attribut type. Le
     * muttateur setType doit modifier la valeur de l'attribut type. La
     * valeur de l'attribut doit être celle du paramètre ou une chaîne vide si cette
     * valeur est null.
     */
    @Test
    public void typeGetterAndSetter_setValue_shouldReturnValue() {

        Book b = new Book("title");
        Copy copyBookB = new Copy(b);
        String expected;
        String actual;

        expected = "";
        actual = copyBookB.getType();
        Assert.assertEquals("L'accesseur getType doit renvoyer une chaîne vide après l'instanciation", expected,
                actual);

        expected = "Science fiction";
        copyBookB.setType(expected);
        actual = copyBookB.getType();
        Assert.assertEquals(
                "Le mutateur setType doit modifier la valeur de l'attribut type et l'accesseur getIsbn doit renvoyer cette valeur.",
                expected, actual);

        expected = "";
        copyBookB.setType(null);
        actual = copyBookB.getType();
        Assert.assertEquals(
                "Si la valeur du paramètre du mutateur setType est null, la valeur de l'attribut type doit être une chaîne vide.",
                expected, actual);
    }

    /**
     * L'accesseur getFormat doit renvoyer la valeur de l'attribut format qui est un enuméré du type CopyFormat.
     * Les valeurs pour CopyFormat ne peuvent être que : PAPERBACK, HARDCOVER et PDF.
     * Le mutateur setFormat doit modifier la valeur de l'attribut format. La valeur de l'attribut
     * doit être celle du paramètre ou null si cette valeur est null.
     */
    @Test
    public void formatGetterAndSetter_setValue_shouldReturnValue() {

        Book b = new Book("title");
        Copy copyBookB = new Copy(b);
        CopyFormat expected;
        CopyFormat actual;

        expected = null;
        actual = copyBookB.getFormat();
        Assert.assertEquals("L'accesseur getFormat doit renvoyer null après l'instanciation", expected,
                actual);

        expected = CopyFormat.PAPERBACK;
        copyBookB.setFormat(CopyFormat.PAPERBACK);
        actual = copyBookB.getFormat();
        Assert.assertEquals(
                "Le mutateur setFormat doit modifier la valeur de l'attribut format et l'accesseur getFromat doit renvoyer cette valeur.",
                expected, actual);

        expected = null;
        copyBookB.setFormat(null);
        actual = copyBookB.getFormat();
        Assert.assertEquals(
                "Si la valeur du paramètre du mutateur setFormat est null, la valeur de l'attribut format doit être également null.",
                expected, actual);
    }

    /**
     * L'accesseur getLocation doit renvoyer la valeur de l'attribut location.
     * Le muttateur setLocation doit modifier la valeur de l'attribut location.
     * La valeur de l'attribut doit être celle du paramètre ou une chaîne vide si
     * cette valeur est null.
     */
    @Test
    public void locationGetterAndSetter_setValue_shouldReturnValue() {

        Book b = new Book("title");
        Copy copyBookB = new Copy(b);
        String expected;
        String actual;

        expected = "";
        actual = copyBookB.getLocation();
        Assert.assertEquals("L'accesseur getLocation doit renvoyer une chaîne vide après l'instanciation", expected,
                actual);

        expected = "A2C34";
        copyBookB.setLocation(expected);
        actual = copyBookB.getLocation();
        Assert.assertEquals(
                "Le mutateur setLocation doit modifier la valeur de l'attribut location et l'accesseur getlocation doit renvoyer cette valeur.",
                expected, actual);

        expected = "";
        copyBookB.setLocation(null);
        actual = copyBookB.getLocation();
        Assert.assertEquals(
                "Si la valeur du paramètre du mutateur setLocation est null, la valeur de l'attribut location doit être une chaîne vide.",
                expected, actual);

    }

}
