package ch.epai.ict.m226.mise_en_route;

/**
 * Création de la classe Copy.
 * 
 * @author Elie Hausmann
 * @version 1.1
 * @since 1.0
 */

public class Copy {

    private String rfid;
    private String type;
    private CopyFormat copyFormat;
    private String location;
    private Book book;

    public Copy(Book book) {
    }

    /**
     * Modifie la variable d'instance rfid.
     * 
     * @param rfid
     * @since 1.0
     */

    public void setRfid(String rfid) {
        if (rfid == "" || rfid == null) {
            this.rfid = "";
        } else {
            this.rfid = rfid;
        }
    }

    /**
     * Lis la variable d'instance rfid.
     * 
     * @return String rfid
     * @since 1.0
     */

    public String getRfid() {
        if (this.rfid == "" || this.rfid == null) {
            this.rfid = "";
        }
        return this.rfid;
    }

    /**
     * Modifie la variable d'instance type.
     * 
     * @param type
     * @since 1.0
     */

    public void setType(String type) {
        if (type == "" || type == null) {
            this.type = "";
        } else {
            this.type = type;
        }
    }

    /**
     * Lis la variable d'instance type.
     * 
     * @return String type
     * @since 1.0
     */

    public String getType() {
        if (this.type == "" || this.type == null) {
            this.type = "";
        }
        return this.type;
    }

    /**
     * Modifie l'enumération FormatCopy.
     * 
     * @param copyFormat
     * @since 1.0
     */

    public void setFormat(CopyFormat copyFormat) {
        this.copyFormat = copyFormat;
    }

    /**
     * Lis l'enumération FormatCopy.
     * 
     * @return FormatCopy
     * @since 1.0
     */

    public CopyFormat getFormat() {
        return this.copyFormat;
    }

    /**
     * Modifie la variable d'instance location.
     * 
     * @param location
     * @since 1.0
     */

    public void setLocation(String location) {
        if (location == "" || location == null) {
            this.location = "";
        } else {
            this.location = location;
        }
    }

    /**
     * Lis la variable d'instance location.
     * 
     * @return String location
     * @since 1.0
     */

    public String getLocation() {
        if (this.location == "" || this.location == null) {
            this.location = "";
        }
        return this.location;
    }

    /**
     * Modifie la variable d'instance book.
     * 
     * @param book
     * @since 1.0
     */

    public void setBook(Book book) {
    }

    /**
     * Lis la variable d'instance book.
     * 
     * @return Book
     * @since 1.0
     */

    public Book getBook() {
        return null;
    }
}