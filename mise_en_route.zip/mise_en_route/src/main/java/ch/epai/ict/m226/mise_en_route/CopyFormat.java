package ch.epai.ict.m226.mise_en_route;

/**
 * Création de l'enumération FormatCopy
 * 
 * @author Elie Hausmann
 * @version 1.0
 * @since 1.0
 */

public enum CopyFormat {
    PAPERBACK, HARDCOVER, PDF
}