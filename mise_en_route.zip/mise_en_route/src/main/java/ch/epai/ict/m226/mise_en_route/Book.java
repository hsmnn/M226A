package ch.epai.ict.m226.mise_en_route;

import java.util.ArrayList;

/**
 * Création de la classe Book.
 * 
 * @author Elie Hausmann
 * @version 1.0
 * @since 1.0
 */

public class Book {

    private String title;
    private String isbn;
    private String publisher;
    private String year;
    private int numOfPages;
    private ArrayList<Author> authors = new ArrayList<Author>();
    private String citation;
    private String authorsName;

    public Book(String title) {
        setTitle(title);
        setIsbn("");
        setPublisher("");
        setYear("");
        setNumOfPages(0);
        setCitation("");
    }

    public Book(String title, String isbn) {
        setTitle(title);
        setIsbn(isbn);
        setPublisher("");
        setYear("");
        setNumOfPages(0);
        setCitation("");
        authors = new ArrayList<Author>();
    }

    public Book(String title, String isbn, String publisher, String year, int numOfPage) {
        setTitle(title);
        setIsbn(isbn);
        setPublisher(publisher);
        setYear(year);
        setNumOfPages(numOfPages);
        setCitation("");
        authors = new ArrayList<Author>();
    }

    /**
     * Modifie la variable d'instance title.
     * 
     * @param title
     * @since 1.0
     */

    public void setTitle(String title) {
        if (title == null) {
            this.title = "";
        } else {
            this.title = title;
        }
    }

    /**
     * Lis la variable d'instance title.
     * 
     * @return String title
     * @since 1.0
     */

    public String getTitle() {
        return title;
    }

    /**
     * Modifie la variable d'instance isbn.
     * 
     * @param isbn
     * @since 1.0
     */

    public void setIsbn(String isbn) {
        if (isbn == null) {
            this.isbn = "";
        } else {
            this.isbn = isbn;
        }
    }

    /**
     * Lis la variable d'instance isbn.
     * 
     * @return String isbn
     * @since 1.0
     */

    public String getIsbn() {
        if (isbn == null) {
            this.isbn = "";
        } else {
        }
        return this.isbn;
    }

    /**
     * Modifie la variable d'instance publisher.
     * 
     * @param publisher
     * @since 1.0
     */

    public void setPublisher(String publisher) {
        if (publisher == null) {
            this.publisher = "";
        } else {
            this.publisher = publisher;
        }
    }

    /**
     * Lis la variable d'instance publisher.
     * 
     * @return String publisher
     * @since 1.0
     */

    public String getPublisher() {
        if (publisher == null) {
            this.publisher = "";
        }
        return this.publisher;
    }

    /**
     * Modifie la variable d'instance year.
     * 
     * @param year
     * @since 1.0
     */

    public void setYear(String year) {
        if (year == null) {
            this.year = "";
        } else {
            this.year = year;
        }
    }

    /**
     * Lis la variable d'instance year.
     * 
     * @return String year
     * @since 1.0
     */

    public String getYear() {
        if (year == null) {
            this.year = "";
        }
        return this.year;
    }

    /**
     * Modifie la variable d'instance NumOfPages.
     * 
     * @param numOfPages
     * @since 1.0
     */

    public void setNumOfPages(int numOfPages) {
        if (numOfPages == 0) {
            numOfPages = 0;
        } else {
            this.numOfPages = numOfPages;
        }
    }

    /**
     * Lis la variable d'instance NumOfPages.
     * 
     * @return int numOfPages
     * @since 1.0
     */

    public int getNumOfPages() {
        if (numOfPages == 0) {
            this.numOfPages = 0;
        }
        return numOfPages;
    }

    /**
     * Modifie la variable d'instance ArrayList<Author>.
     * 
     * @param authors
     * @since 1.0
     */

    public void setAuthors(ArrayList<Author> authors) {
        this.authors = authors;
    }

    /**
     * Lis la variable d'instance ArrayList<Author>.
     * 
     * @return ArrayList<Author> authors
     * @since 1.0
     */

    public ArrayList<Author> getAuthors() {
        return authors;
    }

    /**
     * Modifie la variable d'instance citation.
     * 
     * @param citation
     * @since 1.0
     */

    public void setCitation(String citation) {

    }

    /**
     * Lis la variable d'instance citation.
     * 
     * @return String citation
     * @since 1.0
     */

    public String getCitation() {
        String lastname = "";
        String test = "";
        if (this.year != "" && this.year != null) {
            if (this.authors.size() == 0) {
                String year2 = "(" + this.year + ")";
                return year2;
            }
        }
        if (this.year == "" || this.year == null) {
            if (authors.size() == 1) {
                lastname = "(" + this.authors.get(0).getLastname() + ")";
                return lastname;
            }
        }
        if (this.year == "" || this.year == null) {
            if (authors.size() > 0) {
                String lastnameX = "(";
                for (int i = 0; i < authors.size() - 1; i = i + 1) {
                    lastnameX = lastnameX + this.authors.get(i).getLastname() + ", ";
                    if (i + 2 == authors.size()) {
                        lastnameX = lastnameX + this.authors.get(i + 1).getLastname() + ")";
                    }
                }
                return lastnameX;
            }
        }
        if (year != "") {
            if (authors.size() > 0) {
                String lastnameY = "(";
                for (int k = 0; k < authors.size() - 1; k = k + 1) {
                    lastnameY = lastnameY + this.authors.get(k).getLastname() + ", ";
                    if (k + 2 == authors.size()) {
                        lastnameY = lastnameY + this.authors.get(k + 1).getLastname() + ", " + this.year + ")";
                    }
                }
                return lastnameY;
            }
        }
        return test;
    }
}