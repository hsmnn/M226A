package ch.epai.ict.m226.gerons_nos_livres;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

/**
 * This class represents a concrete Book in the library.
 * 
 * History: 1.0 - Initial version of the class. 1.1 - Add of the borrow
 * functionalities.
 * 
 * @author Elie Hausmann
 * @version 1.1
 * @since 1.0
 */
public class Copy {

    /**
     * Duration of the borrow. Should not change
     */
    private final int BORROW_DURATION_DAY = 30;

    private String rfid;
    private String type;
    private CopyFormat format;
    private String location;
    private LocalDate dueDate;

    /**
     * Borrow date history.
     */
    ArrayList<LocalDate> borrowedDate = new ArrayList<LocalDate>();

    /**
     * Return date history.
     */
    ArrayList<LocalDate> returnedDate = new ArrayList<LocalDate>();

    /**
     * The copy is borrowed or not.
     */
    boolean borrowed;

    private Book book;

    /**
     * Copy constructor.
     * 
     * @param book the definition of the book to put in the library.
     * 
     * @since 1.0
     */
    public Copy(final Book book) {
        setRfid("");
        setType("");
        setFormat(null);
        setLocation("");

        setBook(book);
        setBorrowDate(null);

        borrowedDate = new ArrayList<LocalDate>();
        returnedDate = new ArrayList<LocalDate>();
    }

    /**
     * This function shall return the return's date of the copy.
     * 
     * @return the date of the return's copy.
     * 
     * @since 1.1
     */
    public LocalDate dueDate() {
        LocalDate borrowDate = this.borrowedDate.get(this.borrowedDate.size() - 1);
        this.dueDate = (borrowDate.plus(BORROW_DURATION_DAY, ChronoUnit.DAYS));
        return this.dueDate;
    }

    /**
     * Cette fonction mets dans l'arraylist BorrowedDate la date d'emprunt passer en
     * paramètre.
     * 
     * @param date
     * 
     * @since 1.1
     */
    public void setBorrowDate(LocalDate date) {
        this.borrowedDate.add(date);
    }

    /**
     * Determine if the borrow is overdue.
     * 
     * @return true if the copy is overdue, otherwise false
     * 
     * @since 1.1
     */
    public boolean isOverdue() {
        boolean isOverdue = false;
        LocalDate now = LocalDate.now();

        if (this.borrowed = true) {
            if (now.isAfter(this.dueDate)) {
                isOverdue = true;
            } else {
                isOverdue = false;
            }
        }

        return isOverdue;
    }

    /**
     * Determine if the copy is allready borrowed.
     * 
     * @return true if the copy is borrowed, otherwise false
     * 
     * @since 1.1
     */
    public boolean isBorrowed() {
        if (this.borrowedDate.size() > this.returnedDate.size()) {
            this.borrowed = true;
        } else {
            this.borrowed = false;
        }
        return this.borrowed;
    }

    /**
     * Make a borrow (add an entry into the arralist borrowedDate) of the current
     * Copy only if isn't allready borrowed. Emprunte la copie / le livre physique.
     * 
     * 1. set "borrowed" to true 2. add actual "date to borrowedDate"
     * 
     * @since 1.1
     */
    public void borrowCopy() {
        if (this.borrowed == false) {
            this.borrowed = true;
            this.borrowedDate.add(LocalDate.now());
        }
    }

    /**
     * Return the copy (add an entry into the arralist returnedDate), the return
     * shall be possible only if the Copy is borrowed. Retourne la copie / le livre
     * physique.
     * 
     * 1. set "borrowed" to false 2. add actual date to "returnedDate"
     * 
     * @since 1.1
     */
    public void returnCopy() {
        if (this.borrowed == true) {
            this.borrowed = false;
            this.returnedDate.add(LocalDate.now());
        }
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnedDate.add(returnDate);
    }

    /**
     * Rfid setter
     * 
     * @param rfid of the book's copy.
     * 
     * @since 1.0
     */
    public void setRfid(String rfid) {
        if (rfid != null) {
            this.rfid = rfid;
        } else {
            this.rfid = "";
        }
    }

    /**
     * Rfid getter
     * 
     * @return the rfid of the book's copy.
     * 
     * @since 1.0
     */
    public String getRfid() {
        if (this.rfid == null) {
            this.rfid = "";
        }
        return this.rfid;
    }

    /**
     * Type setter
     * 
     * @param type of the book's copy.
     * 
     * @since 1.0
     */
    public void setType(String type) {
        if (type != null) {
            this.type = type;
        } else {
            this.type = "";
        }
    }

    /**
     * Type getter
     * 
     * @return the type of the book's copy.
     * 
     * @since 1.0
     */
    public String getType() {
        if (this.type == null) {
            this.type = "";
        }
        return this.type;
    }

    /**
     * Format setter
     * 
     * @param format of the book's copy.
     * 
     * @since 1.0
     */
    public void setFormat(CopyFormat format) {
        this.format = format;
    }

    /**
     * Format getter
     * 
     * @return the format of the book's copy.
     * 
     * @since 1.0
     */
    public CopyFormat getFormat() {
        return this.format;
    }

    /**
     * Location setter
     * 
     * @param location of the book's copy.
     * 
     * @since 1.0
     */
    public void setLocation(String location) {
        if (location != null) {
            this.location = location;
        } else {
            this.location = "";
        }
    }

    /**
     * Location getter
     * 
     * @return the location of the book's copy.
     * 
     * @since 1.0
     */
    public String getLocation() {
        if (this.location == null) {
            this.location = "";
        }
        return this.location;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public Book getBook() {
        return this.book;
    }
}