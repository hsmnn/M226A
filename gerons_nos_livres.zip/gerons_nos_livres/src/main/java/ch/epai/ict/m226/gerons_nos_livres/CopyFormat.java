package ch.epai.ict.m226.gerons_nos_livres;

/**
 * Création de l'enumération FormatCopy
 * 
 * @author Elie Hausmann
 * @version 1.0
 * @since 1.0
 */

public enum CopyFormat {
    PAPERBACK, HARDCOVER, PDF
}