package ch.epai.ict.m226.gerons_nos_livres;

/**
 * Création de la classe Author.
 * 
 * @author Elie Hausmann
 * @version 1.0
 * @since 1.0
 */

public class Author {

    String lastname;
    private String firstname;
    private String street;
    private int postalCode;
    private String city;
    private String emailAddress;

    public Author() {
        this.lastname = "";
        this.firstname = "";
        this.street = "";
        this.postalCode = 0;
        this.city = "";
        this.emailAddress = "";
    }

    public Author(String lastname) {
        if (lastname == null) {
            this.lastname = "";
        } else {
            this.lastname = lastname;
        }

        this.lastname = lastname;
        this.street = "";
        this.postalCode = 0;
        this.city = "";
        this.emailAddress = "";
    }

    public Author(String lastname, String firstname) {

        if (lastname == null) {
            this.lastname = "";
        } else {
            this.lastname = lastname;
        }

        if (firstname == null) {
            this.firstname = "";
        } else {
            this.firstname = firstname;
        }

        this.lastname = lastname;
        this.firstname = firstname;
        this.street = "";
        this.postalCode = 0;
        this.city = "";
        this.emailAddress = "";
    }

    /**
     * Modifie la variable d'instance lastname.
     * 
     * @param lastname
     * @since 1.0
     */

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    /**
     * Lis la variable d'instance lastname.
     * 
     * @return String lastname
     * @since 1.0
     */

    public String getLastname() {
        if (lastname == null) {
            this.lastname = "";
        }
        return this.lastname;
    }

    /**
     * Modifie la variable d'instance firstname.
     * 
     * @param firstame
     * @since 1.0
     */

    public void setFirstname(String firstame) {
        this.firstname = firstame;
    }

    /**
     * Lis la variable d'instance firstname.
     * 
     * @return String lastname
     * @since 1.0
     */

    public String getFirstname() {
        if (firstname == null) {
            this.firstname = "";
        }
        return this.firstname;
    }

    /**
     * Lis la variable d'instance fullname.
     * 
     * @return String fullname
     * @since 1.0
     */

    public String getFullName() {
        if (firstname == null) {
            return lastname;
        }
        String fullName = "";
        if (lastname == null || lastname == "") {
            return firstname;
        } else {
            char initial = this.firstname.charAt(0);
            fullName = this.lastname + ", " + initial + ".";
        }
        return fullName;
    }

}