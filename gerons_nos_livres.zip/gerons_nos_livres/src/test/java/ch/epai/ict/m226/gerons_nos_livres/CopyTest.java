package ch.epai.ict.m226.gerons_nos_livres;

import java.time.LocalDate;

import org.junit.*;

public class CopyTest {

        /**
         * La classe Copy doit avoir un constructeur avec la signature Copy(Book book).
         * La valeur du paramètre doit être affectée à l'attribut book. Si la valeur du
         * paramètre est null, la valeur de l'attribut book doit être null.
         */
        @Test
        public void constructor_setTitle_shouldCreateInstance() {
                Book a = new Book("title");
                Copy copyBookA = new Copy(a);
                Assert.assertNotNull(copyBookA);
        }

        /**
         * La méthode dueDate doit renvoyer la date de retour du livre emprunté.
         */
        @Test
        public void dueDate_ShouldReturnReturnsDate() {
                Book b = new Book("title");
                Copy copyBookB = new Copy(b);

                LocalDate borrowedDateTest = LocalDate.of(2019, 10, 1);
                copyBookB.setBorrowDate(borrowedDateTest);

                LocalDate expected = LocalDate.of(2019, 10, 31);

                LocalDate actual = copyBookB.dueDate();
                Assert.assertEquals("La méthode dueDate doir renvoyer la date de retour du livre emprunté.", expected,
                                actual);
        }

        /**
         * La méthode isOverdue détermine si le retour est en retard. Elle devrait, pour
         * ce cas-ci, renvoyer true car le livre n'est toujours pas rendu.
         */
        @Test
        public void isOverdue_ShouldReturnFalse() {
                Book b = new Book("Title");
                Copy copyBookB = new Copy(b);
                boolean expected;
                boolean actual;
                LocalDate borrowDateTest = LocalDate.of(2019, 7, 12);

                copyBookB.setBorrowDate(borrowDateTest);
                copyBookB.dueDate();

                expected = true;
                actual = copyBookB.isOverdue();
                Assert.assertEquals("La méthode isOverdue doit renvoyer false.", expected, actual);
        }

        /**
         * La méthode isOverdue détermine si le retour est en retard. Elle devrait, pour
         * ce cas-ci, renvoyer false car le délai de rente du livre n'est pas encore
         * dépassé.
         */
        @Test
        public void isOverdue_ShouldReturnTrue() {
                Book b = new Book("Title");
                Copy copyBookB = new Copy(b);
                boolean expected;
                boolean actual;
                LocalDate borrowDateTest = LocalDate.now();

                copyBookB.setBorrowDate(borrowDateTest);
                copyBookB.dueDate();

                expected = false;
                actual = copyBookB.isOverdue();
                Assert.assertEquals("La méthode isOverdue doit renvoyer true.", expected, actual);
        }

        /**
         * la méthode isBorrowed détermine si le livre est emprunté ou non. Dans ce cas,
         * la méthode doit renvoyer true car le livre est emprunté.
         */
        @Test
        public void isBorrowed_ShouldReturnTrue() {
                Book b = new Book("Title");
                Copy copyBookB = new Copy(b);
                boolean expected;
                boolean actual;

                LocalDate borrowDate = LocalDate.of(2019, 3, 28);
                copyBookB.setBorrowDate(borrowDate);

                expected = true;
                actual = copyBookB.isBorrowed();
                Assert.assertEquals("La méthode doit renvoyer true car le livre est emprunté.", expected, actual);
        }

        /**
         * la méthode isBorrowed détermine si le livre est emprunté ou non. Dans ce cas,
         * la méthode doit renvoyer false car le livre n'est pas emprunté.
         */
        @Test
        public void isBorrowed_ShouldReturnFalse() {
                Book b = new Book("Title");
                Copy copyBookB = new Copy(b);
                boolean expected;
                boolean actual;

                LocalDate borrowDate = LocalDate.of(2019, 3, 28);
                copyBookB.setBorrowDate(borrowDate);

                LocalDate returnDate = LocalDate.of(2019, 4, 6);
                copyBookB.setReturnDate(returnDate);

                expected = false;
                actual = copyBookB.isBorrowed();
                Assert.assertEquals("La méthode doit renvoyer false car le livre n'est pas emprunté.", expected,
                                actual);
        }

        /**
         * La méthode borrowCopy doit créer un emprunt de livre en passant "borrowed" à
         * true et en entrant la date d'emprunt.
         * 
         * Dans ce cas, le test doit renvoyer true car le livre est emprunté.
         */
        @Test
        public void borrowCopy_ShouldCreatABorrowIfFalse() {
                Book b = new Book("Title");
                Copy copyBookB = new Copy(b);
                boolean expected;
                boolean actual = false;

                copyBookB.borrowed = false;
                copyBookB.borrowCopy();
                if (copyBookB.isBorrowed() == true) {
                        if (copyBookB.borrowedDate.size() > 0) {
                                actual = true;
                        }
                }
                expected = true;
                Assert.assertEquals("La méthode doit renvoyer true car le livre doit être emprunté.", expected, actual);
        }

        /**
         * La méthode borrowCopy doit créer un emprunt de livre en passant "borrowed" à
         * true et en entrant la date d'emprunt.
         * 
         * Dans ce cas, le test doit renvoyer false, car le livre est encore en emprunt
         * et n'est pas rendu. Il ne peut donc pas créer de nouvel emprunt tant que le
         * livre n'est pas rendu.
         */
        @Test
        public void borrowCopy_ShouldCreatABorrowIfTrue() {
                Book b = new Book("Title");
                Copy copyBookB = new Copy(b);
                boolean expected;
                boolean actual = false;

                copyBookB.borrowed = true;
                copyBookB.borrowCopy();
                if (copyBookB.isBorrowed() == true) {
                        if (copyBookB.borrowedDate.size() > 0) {
                                actual = true;
                        }
                } else {
                        actual = false;
                }
                expected = false;
                Assert.assertEquals("La méthode doit renvoyer true car le livre doit être emprunté.", expected, actual);
        }

        /**
         * La méthode returnCopy doit retourner la copie / le livre physique. N'est
         * possible seulement si le livre est emprunté.
         * 
         * Dans ce cas, la méthode doit renvoyer true, car le livre est rendu.
         */
        @Test
        public void returnCopy_ShouldReturnTheCopyIfFalse() {
                Book b = new Book("Title");
                Copy copyBookB = new Copy(b);
                boolean expected;
                boolean actual = false;

                copyBookB.borrowed = false;
                copyBookB.returnCopy();
                if (copyBookB.isBorrowed() == false) {
                        if (copyBookB.returnedDate.size() > 0) {
                                actual = true;
                        }
                } else {
                        actual = false;
                }
                expected = false;
                Assert.assertEquals(
                                "La méthode doit renvoyer false car le livre n'est pas emprunté donc il ne peut être rendu.",
                                expected, actual);
        }

        /**
         * La méthode returnCopy doit retourner la copie / le livre physique. N'est
         * possible seulement si le livre est emprunté.
         * 
         * Dans ce cas, la méthode doit renvoyer false car le livre n'est pas emprenté
         * donc il ne peut être rendu.
         */
        @Test
        public void returnCopy_ShouldReturnTheCopyIfTrue() {
                Book b = new Book("Title");
                Copy copyBookB = new Copy(b);
                boolean expected;
                boolean actual = false;

                copyBookB.borrowed = true;
                copyBookB.returnCopy();
                if (copyBookB.isBorrowed() == false) {
                        if (copyBookB.returnedDate.size() > 0) {
                                actual = true;
                        }
                } else {
                        actual = false;
                }
                expected = true;
                Assert.assertEquals("La méthode doit renvoyer true car le livre doit être rendu.", expected, actual);
        }

        /**
         * L'accesseur getRfid doit renvoyer la valeur de l'attribut rfid. Le mutateur
         * setRfid doit modifier la valeur de l'attribut rfid. La valeur de l'attribut
         * doit être celle du paramètre ou une chaîne vide si cette valeur est null.
         */
        @Test
        public void rfidGetterAndSetter_setValue_shouldReturnValue() {

                Book b = new Book("title");
                Copy copyBookB = new Copy(b);
                String expected;
                String actual;

                expected = "";
                actual = copyBookB.getRfid();
                Assert.assertEquals("L'accesseur getRfid doit renvoyer une chaîne vide après l'instanciation", expected,
                                actual);

                expected = "1234567890";
                copyBookB.setRfid(expected);
                actual = copyBookB.getRfid();
                Assert.assertEquals(
                                "Le mutateur setRfid doit modifier la valeur de l'attribut rfid et l'accesseur getRfid doit renvoyer cette valeur.",
                                expected, actual);

                expected = "";
                copyBookB.setRfid(null);
                actual = copyBookB.getRfid();
                Assert.assertEquals(
                                "Si la valeur du paramètre du mutateur setRfid est null, la valeur de l'attribut rfid doit être une chaîne vide.",
                                expected, actual);
        }

        /**
         * L'accesseur getType doit renvoyer la valeur de l'attribut type. Le muttateur
         * setType doit modifier la valeur de l'attribut type. La valeur de l'attribut
         * doit être celle du paramètre ou une chaîne vide si cette valeur est null.
         */
        @Test
        public void typeGetterAndSetter_setValue_shouldReturnValue() {

                Book b = new Book("title");
                Copy copyBookB = new Copy(b);
                String expected;
                String actual;

                expected = "";
                actual = copyBookB.getType();
                Assert.assertEquals("L'accesseur getType doit renvoyer une chaîne vide après l'instanciation", expected,
                                actual);

                expected = "Science fiction";
                copyBookB.setType(expected);
                actual = copyBookB.getType();
                Assert.assertEquals(
                                "Le mutateur setType doit modifier la valeur de l'attribut type et l'accesseur getIsbn doit renvoyer cette valeur.",
                                expected, actual);

                expected = "";
                copyBookB.setType(null);
                actual = copyBookB.getType();
                Assert.assertEquals(
                                "Si la valeur du paramètre du mutateur setType est null, la valeur de l'attribut type doit être une chaîne vide.",
                                expected, actual);
        }

        /**
         * L'accesseur getFormat doit renvoyer la valeur de l'attribut format qui est un
         * enuméré du type CopyFormat. Les valeurs pour CopyFormat ne peuvent être que :
         * PAPERBACK, HARDCOVER et PDF. Le mutateur setFormat doit modifier la valeur de
         * l'attribut format. La valeur de l'attribut doit être celle du paramètre ou
         * null si cette valeur est null.
         */
        @Test
        public void formatGetterAndSetter_setValue_shouldReturnValue() {

                Book b = new Book("title");
                Copy copyBookB = new Copy(b);
                CopyFormat expected;
                CopyFormat actual;

                expected = null;
                actual = copyBookB.getFormat();
                Assert.assertEquals("L'accesseur getFormat doit renvoyer null après l'instanciation", expected, actual);

                expected = CopyFormat.PAPERBACK;
                copyBookB.setFormat(CopyFormat.PAPERBACK);
                actual = copyBookB.getFormat();
                Assert.assertEquals(
                                "Le mutateur setFormat doit modifier la valeur de l'attribut format et l'accesseur getFromat doit renvoyer cette valeur.",
                                expected, actual);

                expected = null;
                copyBookB.setFormat(null);
                actual = copyBookB.getFormat();
                Assert.assertEquals(
                                "Si la valeur du paramètre du mutateur setFormat est null, la valeur de l'attribut format doit être également null.",
                                expected, actual);
        }

        /**
         * L'accesseur getLocation doit renvoyer la valeur de l'attribut location. Le
         * muttateur setLocation doit modifier la valeur de l'attribut location. La
         * valeur de l'attribut doit être celle du paramètre ou une chaîne vide si cette
         * valeur est null.
         */
        @Test
        public void locationGetterAndSetter_setValue_shouldReturnValue() {

                Book b = new Book("title");
                Copy copyBookB = new Copy(b);
                String expected;
                String actual;

                expected = "";
                actual = copyBookB.getLocation();
                Assert.assertEquals("L'accesseur getLocation doit renvoyer une chaîne vide après l'instanciation",
                                expected, actual);

                expected = "A2C34";
                copyBookB.setLocation(expected);
                actual = copyBookB.getLocation();
                Assert.assertEquals(
                                "Le mutateur setLocation doit modifier la valeur de l'attribut location et l'accesseur getlocation doit renvoyer cette valeur.",
                                expected, actual);

                expected = "";
                copyBookB.setLocation(null);
                actual = copyBookB.getLocation();
                Assert.assertEquals(
                                "Si la valeur du paramètre du mutateur setLocation est null, la valeur de l'attribut location doit être une chaîne vide.",
                                expected, actual);

        }

}
