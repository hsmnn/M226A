package ch.epai.ict.m226.gerons_nos_items_lsp_isp;

/**
 * Représente le nom d'auteur d'un livre du catalogue.
 */
public class Author {

    private String lastName;
    private String firstName;

    /**
     * Constructeur
     *
     * @param lastName  le nom de l'auteur
     * @param firstName le prénom de l'auteur
     */
    public Author(String lastName, String firstName) {
        this.lastName = StringUtils.emptyStringIfNull(lastName);
        this.firstName = StringUtils.emptyStringIfNull(firstName);
    }

    /**
     * Accesseur pour le nom de l'auteur.
     *
     * @return le nom
     */
    public String getLastName() {
        return this.lastName;
    }

    /**
     * Accesseur pour le prénom de l'auteur.
     *
     * @return le prénom
     */
    public String getFirstName() {
        return this.firstName;
    }

    /**
     * Renvoie le nom complet de l'auteur composé de l'initiale de son prénom suivit
     * de son nom.
     *
     * @return le nom complet
     */
    public String getFullName() {
        String data = "";
        if (this.firstName == "") {
            data = this.lastName;
        } else if (this.lastName == "") {
            data = this.firstName;
        } else {
            data = this.firstName.charAt(0) + ". " + this.lastName;
        }
        return data;
    }
}
