package ch.epai.ict.m226.gerons_nos_items_lsp_isp;

public class PersonNameImpl implements PersonName {

    private String firstName;
    private String lastName;

    public PersonNameImpl(String lastName, String firstName) {
        this.firstName = StringUtils.emptyStringIfNull(firstName);
        this.lastName = StringUtils.emptyStringIfNull(lastName);
    }

    @Override
    public String getFirstName() {
        return this.firstName;
    }

    @Override
    public String getLastName() {
        return this.lastName;
    }

    @Override
    public String getFullName() {
        String fullName = "";
        if (this.firstName == "") {
            fullName = this.lastName;
        } else {
            if (this.lastName == "") {
                fullName = this.firstName;
            }else{
                char initial = this.firstName.charAt(0);
                fullName = initial + ". " + this.lastName;
            }
        }
        return fullName;
    }

}