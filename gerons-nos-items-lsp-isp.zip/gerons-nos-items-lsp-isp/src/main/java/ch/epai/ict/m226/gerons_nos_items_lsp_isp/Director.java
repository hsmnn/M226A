package ch.epai.ict.m226.gerons_nos_items_lsp_isp;

public class Director{
    
    private String firstName;
    private String lastName;

    public Director(String lastName, String firstName){
        this.firstName = StringUtils.emptyStringIfNull(firstName);
        this.lastName = StringUtils.emptyStringIfNull(lastName);
    }

    public String getFirstName(){
        return this.firstName;
    }

    public String getLastName(){
        return this.lastName;
    }

    public String getFullName(){
        String fullName = null;

        if (this.firstName == ""){
            fullName = this.lastName;
        }

        if (this.lastName == ""){
            fullName = this.firstName;
        }

        if ((this.firstName != "") && (this.lastName != "")){
            char initial = firstName.charAt(0);
            fullName = initial + ". " + lastName;
        }

        return fullName;
    }
}