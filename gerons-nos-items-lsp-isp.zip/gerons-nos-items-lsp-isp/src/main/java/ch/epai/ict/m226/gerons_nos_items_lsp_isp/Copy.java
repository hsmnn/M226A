package ch.epai.ict.m226.gerons_nos_items_lsp_isp;

public interface Copy {
    public String getId();
    public String getLocation();
    public LibraryItem getItem();
}