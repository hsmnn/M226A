package ch.epai.ict.m226.gerons_nos_items_lsp_isp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Représente un livre dans le catalogue de la bibliothèque.
 */
public class Book implements LibraryItem{

    private String id;
    private String title;
    private String isbn;
    private String publisher;
    private String year;
    private int numOfPages;
    private ArrayList<PersonName> authors = new ArrayList<PersonName>();
    private BookFormat format;
    private String description;
    private String language;

    /**
     * Constructeur
     *
     * @param id         l'identifiant du livre dans le catalogue de la bibliothèque
     * @param title      le titre
     * @param isbn       l'ISBN
     * @param publisher  l'éditeur
     * @param year       l'année du publication
     * @param numOfPages le nombre de pages
     * @param authors    une liste d'auteurs
     * @param format     le format
     * @param description La description
     * @param language   le language
     */
    public Book(String id, String title, String isbn, String publisher, String year,
            int numOfPages, List<PersonNameImpl> authors, BookFormat format, String description, String language) {

        this.id = StringUtils.emptyStringIfNull(id);
        this.title = StringUtils.emptyStringIfNull(title);
        this.isbn = StringUtils.emptyStringIfNull(isbn);
        this.publisher = StringUtils.emptyStringIfNull(publisher);
        this.year = StringUtils.emptyStringIfNull(year);
        this.description = StringUtils.emptyStringIfNull(description);
        this.language = StringUtils.emptyStringIfNull(language);

        this.numOfPages = Math.max(0, numOfPages);

        if (authors != null) {
            this.authors = new ArrayList<PersonName>(authors);
        } else {
            this.authors = new ArrayList<PersonName>();
        }
        this.format = format;
    }

    /**
     * Accesseur pour l'identifiant du livre.
     *
     * @return l'identifiant
     */
    public String getId() {
        return this.id;
    }

    /**
     * Accesseur pour le titre du livre.
     *
     * @return le titre
     */
    public String getTitle() {
        return this.title;
    }

    /**
     * Accesseur pour l'ISBN du livre.
     *
     * @return l'ISBN
     */
    public String getIsbn() {
        return this.isbn;
    }

    /**
     * Accesseur pour l'éditeur du livre.
     *
     * @return l'éditeur
     */
    public String getPublisher() {
        return this.publisher;
    }

    /**
     * Accesseur pour l'année de publication du livre.
     *
     * @return l'année de publication
     */
    public String getYear() {
        return this.year;
    }

    /**
     * Accesseur pour le nombre de pages du livre.
     *
     * @return le nombre de pages
     */
    public int getNumOfPages() {
        return this.numOfPages;
    }

    /**
     * Accesseur pour les auteurs du livre.
     *
     * @return une vue non modifiable de la liste d'auteurs
     */
    public List<PersonName> getAuthors() {
        return Collections.unmodifiableList(this.authors);
    }

    /**
     * Renvoie une chaîne qui contient les noms complet (fullName) des auteurs
     * séparés par des virgules.
     *
     * @return la liste des auteurss
     */
    public String getAuthorsNames() {
        String result = "";
        for (int i = 0; i < this.authors.size(); i = i + 1) {
            if (i > 0) {
                result = result + ", ";
            }
            result = result + this.authors.get(i).getFullName();
        }
        return result;
    }

    /**
     * Accesseur pour le format du livre.
     *
     * @return le format du livre
     */
    public BookFormat getFormat() {
        return this.format;
    }

    public String getDescription(){
        return this.description;
    }

    public String getLanguage(){
        return this.language;
    }

    public String getKindOfItem(){
        return "BOOK";
    }
}
