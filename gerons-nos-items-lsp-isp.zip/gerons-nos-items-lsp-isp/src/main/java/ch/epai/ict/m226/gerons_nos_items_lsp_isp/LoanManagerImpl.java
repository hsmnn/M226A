package ch.epai.ict.m226.gerons_nos_items_lsp_isp;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class LoanManagerImpl implements LoanManager {

    private ArrayList <LoanImpl> loans;

    public LoanManagerImpl() {
    }

    @Override
    public List<LoanImpl> getLoans() {
        return null;
    }

    @Override
    public void loanCopy(String copyId, String borrowerId) {
        this.loans.add(new LoanImpl(copyId, LocalDate.now(), borrowerId));
    }

    @Override
    public void loanCopy(String copyId, String borrowerId, LocalDate date) {
        this.loans.add(new LoanImpl(copyId, date, borrowerId));
    }

    @Override
    public void returnCopy(String copyId) {
        for (int i = 0; i < this.loans.size(); i += 1){
            if (copyId == this.loans.get(i).getCopyId()) {
                this.loans.get(i).returnCopy(LocalDate.now());
            }
        }
    }

    @Override
    public void returnCopy(String copyId, LocalDate date) {
        for (int i = 0; i < this.loans.size(); i += 1){
            if (copyId == this.loans.get(i).getCopyId()) {
                this.loans.get(i).returnCopy(date);
            }
        }
    }

    @Override
    public LocalDate getDueDate(String copyId) {
        LocalDate dueDate = null;
        if (copyId == this.loans.getCopyId()) {
            dueDate = this.loans.getDueDate();
        }
        return dueDate;
    }

    @Override
    public boolean isBorrowed(String copyId) {
        boolean isBorrowed = false;
        if (copyId == this.loans.getCopyId()) {
            if (this.loans.isReturned() == true){
                isBorrowed = false;
            }else{
                isBorrowed = true;
            }
        }
        return isBorrowed;
    }

    @Override
    public boolean isOverdue(String copyId) {
        boolean isOverdue = false;
        if (copyId == this.loans.getCopyId()) {
            if (this.loans.isOverdue() == true){
                isOverdue = true;
            }else{
                isOverdue = false;
            }
        }
        return isOverdue;
    }

    @Override
    public Loan findCurrentLoan(String copyId) {
        return null;
    }
}