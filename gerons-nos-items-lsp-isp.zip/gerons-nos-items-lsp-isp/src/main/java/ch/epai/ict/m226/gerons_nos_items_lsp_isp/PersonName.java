package ch.epai.ict.m226.gerons_nos_items_lsp_isp;

public interface PersonName{
    public String getFirstName();
    public String getLastName();
    public String getFullName();
}