package ch.epai.ict.m226.gerons_nos_items_lsp_isp;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Documentary implements LibraryItem {

    private String id;
    private String title;
    private ArrayList<PersonName> writer = new ArrayList<PersonName>();
    private ArrayList<PersonName> director = new ArrayList<PersonName>();
    private LocalDate launchDate;
    private String description;
    private String language;

    public Documentary (String id, String title, ArrayList<PersonName> director, ArrayList<PersonName> writer, LocalDate launchDate, String description, String language){
        this.id = StringUtils.emptyStringIfNull(id);
        this.title = StringUtils.emptyStringIfNull(title);
        this.description = StringUtils.emptyStringIfNull(description);
        this.language = StringUtils.emptyStringIfNull(language);

        if (director != null) {
            this.director = new ArrayList<PersonName>(director);
        } else {
            this.director = new ArrayList<PersonName>();
        }
        if (writer != null) {
            this.writer = new ArrayList<PersonName>(writer);
        } else {
            this.writer = new ArrayList<PersonName>();
        }
        this.launchDate = launchDate;
    }

    @Override
    public String getId() {
        return this.id;
    }

    @Override
    public String getTitle() {
        return this.title;
    }

    @Override
    public String getDescription() {
        return this.description;
    }

    @Override
    public String getLanguage() {
        return this.language;
    }

    @Override
    public String getKindOfItem() {
        return "DOCUMENTARY";
    }

    public String getDirectorsNames(){
        String directorsNames = "";
        char initial = 'a';
        if (this.director.size() >  1){
            for (int i = 0; i < this.director.size(); i += 1){
                if (i + 1 == this.director.size()){
                    directorsNames += this.director.get(i).getFirstName().charAt(0) + ". " + this.director.get(i).getLastName();
                }else{
                    directorsNames += this.director.get(i).getFirstName().charAt(0) + ". " + this.director.get(i).getLastName() +  ", ";
                }
            }
        }
        return directorsNames;
    }

    public String getWritersNames(){
        String writersNames = "";
        char initial = 'a';
        if (this.writer.size() >  1){
            for (int i = 0; i < this.writer.size(); i += 1){
                if (i + 1 == this.writer.size()){
                    writersNames += this.writer.get(i).getFirstName().charAt(0) + ". " + this.writer.get(i).getLastName();
                }else{
                    writersNames += this.writer.get(i).getFirstName().charAt(0) + ". " + this.writer.get(i).getLastName() +  ", ";
                }
            }
        }
        return writersNames;
    }

    public List<PersonName> getDirectors(){
        return this.director;
    }

    public List<PersonName> getWriters(){
        return this.writer;
    }

    public String getLaunchDate(){
        if (this.launchDate == null){
            return "";
        }
        return launchDate.format(DateTimeFormatter.BASIC_ISO_DATE);
    }
}