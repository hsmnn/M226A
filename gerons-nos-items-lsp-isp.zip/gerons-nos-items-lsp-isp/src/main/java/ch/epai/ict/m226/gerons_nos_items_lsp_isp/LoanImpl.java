package ch.epai.ict.m226.gerons_nos_items_lsp_isp;

import java.time.LocalDate;

import javax.swing.event.PopupMenuEvent;

public class LoanImpl implements Loan {

    private int BORROW_DURATION_NUM_DAY = 30;
    private String copyId;
    private LocalDate loanDate;
    private String borrowerId;
    private LocalDate returnDate;

    public LoanImpl(String copyId, LocalDate loanDate, String borrowerId) {
        this.copyId = copyId;
        if (borrowerId == null) {
            this.borrowerId = "";
        } else {
            this.borrowerId = borrowerId;
        }
        if (loanDate == null) {
            this.loanDate = LocalDate.now();
        } else {
            this.loanDate = loanDate;
        }
        this.returnDate = null;
    }

    public LocalDate getLoanDate() {
        return this.loanDate;
    }

    public LocalDate getReturnDate() {
        return this.returnDate;
    }

    @Override
    public void returnCopy(LocalDate date) {
        this.returnDate = date;
    }

    @Override
    public boolean isReturned() {
        boolean isReturned = false;
        if (returnDate == null) {
            isReturned = false;
        } else {
            isReturned = true;
        }
        return isReturned;
    }

    @Override
    public LocalDate getDueDate() {
        return this.loanDate.plusDays(this.BORROW_DURATION_NUM_DAY);
    }

    @Override
    public boolean isOverdue() {
        boolean isOVerdue = false;
        if (this.loanDate.isAfter(LocalDate.now().plusDays(-this.BORROW_DURATION_NUM_DAY))) {
            return false;
        }
        if (this.loanDate.isBefore(LocalDate.now().plusDays(-30)) && this.returnDate == null) {
            return true;
        }
        if (this.returnDate.isAfter(this.getDueDate())) {
            return true;
        }
        return isOVerdue;
    }

    @Override
    public String getCopyId() {
        return this.copyId;
    }

    @Override
    public String getBorrowerId() {
        return this.borrowerId;
    }
}