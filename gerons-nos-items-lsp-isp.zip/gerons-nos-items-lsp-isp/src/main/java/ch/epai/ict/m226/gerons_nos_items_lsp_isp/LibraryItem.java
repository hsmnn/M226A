package ch.epai.ict.m226.gerons_nos_items_lsp_isp;

public interface LibraryItem {
    public String getId();
    public String getTitle();
    public String getDescription();
    public String getLanguage();
    public String getKindOfItem();
}