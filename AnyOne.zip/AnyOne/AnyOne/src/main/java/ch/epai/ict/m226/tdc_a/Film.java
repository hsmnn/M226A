package ch.epai.ict.m226.tdc_a;

public interface Film {

    public String getId();
    public String getTitre();
    public String getDescription();
    public String getAuteur();
    
}