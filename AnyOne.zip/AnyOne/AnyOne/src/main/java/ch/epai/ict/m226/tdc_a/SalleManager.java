package ch.epai.ict.m226.tdc_a;

import java.util.List;

public interface SalleManager {

    public void addSalle(Salle salle);
    public void removeSalleById(String id);
    public List<Salle> getAllSalles();
    public Salle getSalleById(String id);
    
}