package ch.epai.ict.m226.tdc_a;


public class FilmImpl implements Film{

    private String id;
    private String titre;
    private String description;
    private String auteur;


	public FilmImpl(String id, String titre, String description, String auteur){

        this.id = id;
        this. titre = titre;
        this.description = description;
        this.auteur = auteur;

    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getTitre() {
        return titre;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public String getAuteur() {
        return auteur;
    }

    
    
}