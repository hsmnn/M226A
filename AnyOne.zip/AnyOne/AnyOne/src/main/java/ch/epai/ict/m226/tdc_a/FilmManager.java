package ch.epai.ict.m226.tdc_a;

import java.util.List;

public interface FilmManager {

    public void addFilm(Film film);
    public void removeFilmById(String id);
    public List<Film> getAllFilms();
    public Film getFilmById(String id);
        
    
}