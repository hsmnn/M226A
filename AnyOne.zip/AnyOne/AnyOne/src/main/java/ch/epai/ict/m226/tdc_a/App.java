package ch.epai.ict.m226.tdc_a;

/**
 * TDC M226A
 *
 */
public class App
{
    public static void main( String[] args )
    {
        System.out.println( "Veuillez vous référer aux tests unitaires pour vérifier si vos classes sont correctement implémentées!" );
    }
}
