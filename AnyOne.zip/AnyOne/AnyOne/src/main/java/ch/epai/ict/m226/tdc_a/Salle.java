package ch.epai.ict.m226.tdc_a;

public interface Salle {

    public String getId();
    public String getNom();
    public int getNombrePlaces();

}