package ch.epai.ict.m226.tdc_a;

import java.util.List;

public interface ProjectionManager {

public void addProjection(Projection projection);
public void removeProjectionById(String id);
public List<Projection> getProjectionByDay(String jour);
public List<Projection> getProjectionBySalle(Salle salle);
public List<Projection> getAllProjections();

}