package ch.epai.ict.m226.tdc_a;

public interface Projection {

    public String getId();
    public Film getFilm();
    public Salle getSalle();
    public String getJour();
    public String getHeure();


    
}