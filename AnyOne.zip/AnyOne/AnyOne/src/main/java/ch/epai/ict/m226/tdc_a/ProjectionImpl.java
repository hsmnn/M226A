package ch.epai.ict.m226.tdc_a;


public class ProjectionImpl implements Projection{


    private String id;
    private String jour;
    private String heure;
    private Film film;
    private Salle salle;

    public ProjectionImpl(String id, Film film, Salle salle, String jour, String heure) {

        this.id = id;
        this.jour = jour;
        this.heure = heure;
        this.film = film;
        this.heure = heure;
        this.salle = salle;

    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public Film getFilm() {
        return film;
    }

    @Override
    public Salle getSalle() {
        return salle;
    }

    @Override
    public String getJour() {
        return jour;
    }

    @Override
    public String getHeure() {
        return heure;
    }

    
    
}