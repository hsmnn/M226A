package ch.epai.ict.m226.tdc_a;

import java.util.ArrayList;
import java.util.List;

public class ProjectionManagerImpl implements ProjectionManager {

    private List<Projection> projections;

    public ProjectionManagerImpl() {
        this.projections = new ArrayList<Projection>();
    }

    @Override
    public void addProjection(Projection projection) {
        this.projections.add(projection);
    }

    @Override
    public void removeProjectionById(String id) {
        for (int i = 0; i < this.projections.size(); i += 1){
            if (this.projections.get(i).getId().equals(id)){
                this.projections.remove(i);
            }
        }
    }

    @Override
    public List<Projection> getProjectionByDay(String jour) {
        List<Projection> projection = new ArrayList<Projection>();
        for (int i = 0; i < projections.size(); i += 1) {
            if (jour.equals(projections.get(i).getJour())){
                projection.add(this.projections.get(i));
            }
        }
        return projection;
    }

    @Override
    public List<Projection> getProjectionBySalle(Salle salle) {
        List<Projection> projection = new ArrayList<Projection>();
        for (int i = 0; i < projections.size(); i += 1) {
            if (salle.equals(projections.get(i).getSalle())){
                projection.add(this.projections.get(i));
            }
        }
        return projection;
    }

    @Override
    public List<Projection> getAllProjections() {
        return this.projections;
    }

}