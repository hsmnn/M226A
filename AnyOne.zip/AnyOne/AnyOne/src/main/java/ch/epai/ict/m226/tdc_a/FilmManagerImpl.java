package ch.epai.ict.m226.tdc_a;

import java.util.ArrayList;
import java.util.List;

/**
* Cette classe FIlmManagerImpl implémente l'interface FilmManager
* 
*
* @author  Matthieu Scerri
* @version 1.0
* @since   2018-11-15 
*/

public class FilmManagerImpl implements FilmManager {

    private List<Film> films;   //créé une liste films

    public FilmManagerImpl() { // constructeur
       this.films = new ArrayList<Film>();
    }

    @Override
    public void addFilm(Film film) {    //ajoute un film à la liste film
        this.films.add(film);
    }

    @Override
    public void removeFilmById(String id) {     //enblève des films avec leur identifiant
        for (int i = 0; i < this.films.size(); i += 1){
            if (this.films.get(i).getId().equals(id)){
                this.films.remove(i);
            }
        }
    }

    @Override
    public List<Film> getAllFilms() { //mets tous les films dans la liste films
        return films;
    }

    @Override
    public Film getFilmById(String id) {    //mets les films par leur ID dans la liste films
        for (int i = 0; i < this.films.size(); i += 1){
            if (this.films.get(i).getId().equals(id)){
                return this.films.get(i);
            }
        }
        return null;
    }

    
}