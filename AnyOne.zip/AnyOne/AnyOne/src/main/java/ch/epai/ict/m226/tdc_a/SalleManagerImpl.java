package ch.epai.ict.m226.tdc_a;

import java.util.ArrayList;
import java.util.List;

public class SalleManagerImpl implements SalleManager {

    private List<Salle> salles;

    public SalleManagerImpl (){
        this.salles = new ArrayList<Salle>();
    }

    @Override
    public void addSalle(Salle salle) {
        salles.add(salle);
    }

    @Override
    public void removeSalleById(String id) {
        for (int i = 0; i < this.salles.size(); i += 0){
            if (this.salles.get(i).getId().equals(id)){
                this.salles.remove(i);
            }
        }
    }

    @Override
    public List<Salle> getAllSalles() {
        return this.salles;
    }

    @Override
    public Salle getSalleById(String id) {
        for (int i = 0; i < this.salles.size(); i += 0){
            if (this.salles.get(i).getId().equals(id)){
                return this.salles.get(i);
            }
        }
        return null;
    }

}