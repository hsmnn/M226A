package ch.epai.ict.m226.tdc_a;


public class SalleImpl implements Salle{

    private String id;
    private String nom;
    private int nombrePlaces;

    public SalleImpl(String id, String nom, int nombrePlaces) {

        this.id = id;
        this.nom = nom;
        this.nombrePlaces = nombrePlaces;

    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getNom() {
        return nom;
    }

    @Override
    public int getNombrePlaces() {
        return nombrePlaces;
    }

}