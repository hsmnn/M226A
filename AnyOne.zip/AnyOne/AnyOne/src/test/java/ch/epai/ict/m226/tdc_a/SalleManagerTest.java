package ch.epai.ict.m226.tdc_a;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Tests unitaires pour la classe SalleManager
 *
 * @author mauronf
 */
public class SalleManagerTest {

    private final Salle SALLE_101 = new SalleImpl("id101", "101", 101);
    private final Salle SALLE_102 = new SalleImpl("id102", "102", 102);

    public SalleManagerTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of addSalle method, of class SalleManager.
     */
    @Test
    public void testAddSalle() {
        System.out.println("addSalle");
        SalleManager instance = new SalleManagerImpl();
        assertEquals(instance.getAllSalles().size(), 0);
        instance.addSalle(SALLE_101);
        assertEquals(instance.getAllSalles().size(), 1);
    }

    /**
     * Test of removeSalleById method, of class SalleManager.
     */
    @Test
    public void testRemoveSalleById() {
        System.out.println("removeSalleById");
        SalleManager instance = new SalleManagerImpl();
        instance.addSalle(SALLE_101);
        instance.addSalle(SALLE_102);
        assertEquals(2, instance.getAllSalles().size());
        instance.removeSalleById(SALLE_101.getId());
        assertEquals(1, instance.getAllSalles().size());
        Salle Salle = instance.getAllSalles().get(0);
        assertEquals(SALLE_102.getId(), Salle.getId());
    }

    /**
     * Test of getSalleById method, of class SalleManager.
     */
    @Test
    public void testGetSalleById() {
        System.out.println("getSalleById");
        SalleManager instance = new SalleManagerImpl();
        instance.addSalle(SALLE_101);
        instance.addSalle(SALLE_102);
        Salle result1 = instance.getSalleById("id101");
        assertEquals(SALLE_101, result1);
        Salle result2 = instance.getSalleById("id102");
        assertEquals(SALLE_102, result2);
        Salle result3 = instance.getSalleById("id103");
        assertNull(result3);
    }

    /**
     * Test of getAllSalles method, of class SalleManager.
     */
    @Test
    public void testGetAllSalles() {
        System.out.println("getAllSalles");
        SalleManager instance = new SalleManagerImpl();
        instance.addSalle(SALLE_101);
        instance.addSalle(SALLE_102);
        List<Salle> result = instance.getAllSalles();
        assertEquals(2, result.size());
    }

}
