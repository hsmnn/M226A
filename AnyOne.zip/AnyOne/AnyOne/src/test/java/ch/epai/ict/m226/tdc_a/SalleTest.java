package ch.epai.ict.m226.tdc_a;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Tests unitaires pour la classe Salle
 * 
 * @author frossardj
 * @author mauronf
 */
public class SalleTest {
    
    private final String ID = "1001";
    private final String NOM = "une salle";
    private final int NOMBRE_PLACES = 2000;
    
    private Salle salle;
    
    
    
    public SalleTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        salle = new SalleImpl(ID, NOM, NOMBRE_PLACES);
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getId method, of class Salle.
     */
    @Test
    public void testGetId() {
        System.out.println("getId");
        Salle instance = salle;
        String expResult = ID;
        String result = instance.getId();
        assertEquals(expResult, result);
    }

    /**
     * Test of getNom method, of class Salle.
     */
    @Test
    public void testGetNom() {
        System.out.println("getNom");
        Salle instance = salle;
        String expResult = NOM;
        String result = instance.getNom();
        assertEquals(expResult, result);
    }

    /**
     * Test of getNombrePlace method, of class Salle.
     */
    @Test
    public void testGetNombrePlaces() {
        System.out.println("getNombrePlaces");
        Salle instance = salle;
        int expResult = NOMBRE_PLACES;
        int result = instance.getNombrePlaces();
        assertEquals(expResult, result);
    }
    
}
