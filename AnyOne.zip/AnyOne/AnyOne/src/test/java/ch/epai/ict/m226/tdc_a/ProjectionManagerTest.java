package ch.epai.ict.m226.tdc_a;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Tests unitaires pour la classe SalleManager
 *
 * @author mauronf
 */
public class ProjectionManagerTest {

    private final Salle SALLE_101 = new SalleImpl("id101", "101", 101);
    private final Film FILM_101 = new FilmImpl("id101", "101", "Description_101", "Auteur_101");
    private final Salle SALLE_102 = new SalleImpl("id102", "102", 102);
    private final Film FILM_102 = new FilmImpl("id102", "102", "Description_102", "Auteur_102");
    private final Salle SALLE_103 = new SalleImpl("id103", "103", 103);
    private final Film FILM_103 = new FilmImpl("id103", "103", "Description_103", "Auteur_103");

    private final Projection PROJECTION_101 = new ProjectionImpl("P101", FILM_101, SALLE_101, "jeudi", "20:45");
    private final Projection PROJECTION_102 = new ProjectionImpl("P102", FILM_102, SALLE_101, "vendredi", "19:30");
    private final Projection PROJECTION_103 = new ProjectionImpl("P103", FILM_103, SALLE_103, "jeudi", "21:15");

    public ProjectionManagerTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of addProjection method, of class ProjectionManager.
     */
    @Test
    public void testAddProjection() {
        System.out.println("addProjection");
        ProjectionManager instance = new ProjectionManagerImpl();

        assertEquals(instance.getAllProjections().size(), 0);
        instance.addProjection(PROJECTION_101);
        assertEquals(instance.getAllProjections().size(), 1);
    }

    /**
     * Test of removeProjectionById method, of class ProjectionManager.
     */
    @Test
    public void testRemoveProjectionById() {
        System.out.println("removeProjectionById");

        ProjectionManager instance = new ProjectionManagerImpl();
        instance.addProjection(PROJECTION_101);
        instance.addProjection(PROJECTION_102);
        instance.addProjection(PROJECTION_103);
        assertEquals(3, instance.getAllProjections().size());
        instance.removeProjectionById(PROJECTION_101.getId());
        assertEquals(2, instance.getAllProjections().size());
        Projection projection = instance.getAllProjections().get(0);
        assertEquals(PROJECTION_102.getId(), projection.getId());
    }

    /**
     * Test of getProjectionByDay method, of class ProjectionManager.
     */
    @Test
    public void testGetProjectionByDay() {
        System.out.println("getProjectionByDay");
        ProjectionManager instance = new ProjectionManagerImpl();
        instance.addProjection(PROJECTION_101);
        instance.addProjection(PROJECTION_102);
        instance.addProjection(PROJECTION_103);
        List<Projection> result1 = instance.getProjectionByDay("jeudi");
        assertEquals(2, result1.size());
        List<Projection> result2 = instance.getProjectionByDay("vendredi");
        assertEquals(1, result2.size());
        List<Projection> result3 = instance.getProjectionByDay("samedi");
        assertEquals(0, result3.size());
    }

    /**
     * Test of getProjectionBySalle method, of class ProjectionManager.
     */
    @Test
    public void testGetProjectionBySalle() {
        System.out.println("getProjectionBySalle");
        ProjectionManager instance = new ProjectionManagerImpl();
        instance.addProjection(PROJECTION_101);
        instance.addProjection(PROJECTION_102);
        instance.addProjection(PROJECTION_103);
        List<Projection> result1 = instance.getProjectionBySalle(SALLE_101);
        assertEquals(2, result1.size());
        List<Projection> result2 = instance.getProjectionBySalle(SALLE_103);
        assertEquals(1, result2.size());
        List<Projection> result3 = instance.getProjectionBySalle(SALLE_102);
        assertEquals(0, result3.size());
    }


    /**
     * Test of getAllProjections method, of class ProjectionManager.
     */
    @Test
    public void testGetAllProjections() {
        System.out.println("getAllProjections");
        ProjectionManager instance = new ProjectionManagerImpl();
        instance.addProjection(PROJECTION_101);
        instance.addProjection(PROJECTION_102);
        instance.addProjection(PROJECTION_103);

        List<Projection> result = instance.getAllProjections();
        assertEquals(3, result.size());
    }

}
