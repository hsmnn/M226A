package ch.epai.ict.m226.tdc_a;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Tests unitaire pour la classe projection
 * 
 * @author frossardj
 * @author mauronf
 */
public class ProjectionTest {
        
    private String id;
    private Salle salle;
    private Film film;
    private String jour;
    private String heure;
    private Projection projection;
   
    public ProjectionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        id = "id1001";
        jour = "Lundi";
        heure = "12:00";
        salle = new SalleImpl("10", "Salle1", 200);
        film = new FilmImpl("100", "un film", "une description", "un auteur");
        projection = new ProjectionImpl(id, film, salle, jour, heure);
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getSalle method, of class Projection.
     */
    @Test
    public void testGetSalle() {
        System.out.println("getSalle");
        Projection instance = projection;
        Salle expResult = salle;
        Salle result = instance.getSalle();
        assertEquals(expResult, result);
    }

    /**
     * Test of getFilm method, of class Projection.
     */
    @Test
    public void testGetFilm() {
        System.out.println("getFilm");
        Projection instance = projection;
        Film expResult = film;
        Film result = instance.getFilm();
        assertEquals(expResult, result);
    }

     /**
     * Test of getJour method, of class Projection.
     */
    @Test
    public void testGetJour() {
        System.out.println("getJour");
        Projection instance = projection;
        String expResult = jour;
        String result = instance.getJour();
        assertEquals(expResult, result);
    }
    
    /**
     * Test of getHeure method, of class Projection.
     */
    @Test
    public void testGetHeure() {
        System.out.println("getHeure");
        Projection instance = projection;
        String expResult = heure;
        String result = instance.getHeure();
        assertEquals(expResult, result);
    }
    
}
