package ch.epai.ict.m226.tdc_a;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Tests unitaires pour la classe Film
 * 
 * @author frossardj
 * @author mauronf
 */
public class FilmTest {
    
    private final String ID = "101";
    private final String TITRE = "un titre";
    private final String DESCRIPTION = "une description";
    private final String AUTEUR = "un autheur";

    private Film film;

    public FilmTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        film = new FilmImpl(ID, TITRE, DESCRIPTION, AUTEUR);
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getId method, of class Film.
     */
    @Test
    public void testGetId() {
        System.out.println("getId");
        Film instance = film;
        String expResult = ID;
        String result = instance.getId();
        assertEquals(expResult, result);

    }

    /**
     * Test of getTitre method, of class Film.
     */
    @Test
    public void testGetTitre() {
        System.out.println("getTitre");
        Film instance = film;
        String expResult = TITRE;
        String result = instance.getTitre();
        assertEquals(expResult, result);
    }

    /**
     * Test of getDescription method, of class Film.
     */
    @Test
    public void testGetDescription() {
        System.out.println("getDescription");
        Film instance = film;
        String expResult = DESCRIPTION;
        String result = instance.getDescription();
        assertEquals(expResult, result);
    }

    /**
     * Test of getAuteur method, of class Film.
     */
    @Test
    public void testGetAuteur() {
        System.out.println("getAuteur");
        Film instance = film;
        String expResult = AUTEUR;
        String result = instance.getAuteur();
        assertEquals(expResult, result);
    }
    
}
