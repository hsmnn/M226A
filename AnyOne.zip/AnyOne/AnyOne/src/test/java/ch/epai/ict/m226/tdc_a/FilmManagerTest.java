package ch.epai.ict.m226.tdc_a;

import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Tests unitaires pour la classe FilmManager
 * 
 * @author frossardj
 * @author mauronf
 */
public class FilmManagerTest {
    
    private final Film FILM_101 = new FilmImpl("101", "101", "101", "101");
    private final Film FILM_102 = new FilmImpl("102", "102", "102", "102");
        
    public FilmManagerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of addFilm method, of class FilmManager.
     */
    @Test
    public void testAddFilm() {
        System.out.println("addFilm");
        FilmManager instance = new FilmManagerImpl();
        assertEquals(instance.getAllFilms().size(), 0);
        instance.addFilm(FILM_101);
        assertEquals(instance.getAllFilms().size(), 1);
    }

    /**
     * Test of removeFilmById method, of class FilmManager.
     */
    @Test
    public void testRemoveFilmById() {
        System.out.println("removeFilmById");
        FilmManager instance = new FilmManagerImpl();
        instance.addFilm(FILM_101);
        instance.addFilm(FILM_102);
        assertEquals(2, instance.getAllFilms().size());
        instance.removeFilmById(FILM_101.getId());
        assertEquals(1, instance.getAllFilms().size());
        Film film = instance.getAllFilms().get(0);
        assertEquals(FILM_102.getId(), film.getId());
    }

    /**
     * Test of getFilmById method, of class FilmManager.
     */
    @Test
    public void testGetFilmById() {
        System.out.println("getFilmById");
        FilmManager instance = new FilmManagerImpl();
        instance.addFilm(FILM_101);
        instance.addFilm(FILM_102);
        Film result1 = instance.getFilmById("101");
        assertEquals(FILM_101, result1);
        Film result2 = instance.getFilmById("102");
        assertEquals(FILM_102, result2);               
        Film result3 = instance.getFilmById("103");
        assertNull(result3);
    }

    /**
     * Test of getAllFilm method, of class FilmManager.
     */
    @Test
    public void testGetAllFilm() {
        System.out.println("getAllFilm");
        FilmManager instance = new FilmManagerImpl();
        instance.addFilm(FILM_101);
        instance.addFilm(FILM_102);
        List<Film> result = instance.getAllFilms();
        assertEquals(2, result.size());
    }
    
}
