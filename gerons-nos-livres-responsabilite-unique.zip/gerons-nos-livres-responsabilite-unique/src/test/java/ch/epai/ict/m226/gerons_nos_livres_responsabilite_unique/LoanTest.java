package ch.epai.ict.m226.gerons_nos_livres_responsabilite_unique;

import org.junit.*;

import java.time.LocalDate;

public class LoanTest {

    /**
     * La classe Loan doit avoir un constructeur avec la signature Loan(Copy copy,
     * LocalDate loanDate, String borrower).
     */
    @Test
    public void constructor_shouldCreateInstance() {

        // Test case with all null parameters
        Copy copyExpected = null;
        LocalDate loanDateExpected = LocalDate.now();
        LocalDate returnDateExpected = null;
        String borrowerExpected = "";

        Loan loan = new Loan(null, null, null);
        Assert.assertNotNull(loan);
        Assert.assertEquals(copyExpected, loan.getCopy());
        Assert.assertEquals(loanDateExpected, loan.getLoanDate());
        Assert.assertEquals(returnDateExpected, loan.getReturnDate());
        Assert.assertEquals(borrowerExpected, loan.getBorrowerName());


        // Test case with not null parameters
        Book book = new Book("title");
        Copy copy = new Copy("rfid", CopyFormat.HARDCOVER, "location", book);
        copyExpected = copy;
        loanDateExpected = LocalDate.now();
        returnDateExpected = null;
        borrowerExpected = "Mr. Robot";

        loan = new Loan(copy, LocalDate.now(), "Mr. Robot");
        Assert.assertNotNull("L'objet loan ne peut pas être null.", loan);
        Assert.assertEquals("La copy enregistrée doit correspondre à la copy passée en paramètre", copyExpected,
                loan.getCopy());
        Assert.assertEquals("La LocalDate du prêt doit entre iniaitalisée.", loanDateExpected,
                loan.getLoanDate());
        Assert.assertEquals("La LocalDate de retour doit être null.", returnDateExpected, loan.getReturnDate());
        Assert.assertEquals("L'emprenteur doit être initialisé.", borrowerExpected, loan.getBorrowerName());

    }

    /**
     * returnCopy doit enregistrer la LocalDate de retour de la copie prêtée.
     */
    @Test
    public void returnCopy_shouldStoreReturnDate() {

        Book book = new Book("title");
        Copy copy = new Copy("rfid", CopyFormat.HARDCOVER, "location", book);
        LocalDate returnDateExpected = null;

        Loan loan = new Loan(copy, LocalDate.now(), "Mr. Robot");

        returnDateExpected = LocalDate.now();

        loan.returnCopy(LocalDate.now());
        returnDateExpected = LocalDate.now();
        Assert.assertEquals("La LocalDate de retour doit être la LocalDate courente", returnDateExpected,
                loan.getReturnDate());

    }

    /**
     * Si l'emprunt n'est pas revenu, isReturned doit renvoyer faux.
     */
    @Test
    public void isReturned_notReturned_shouldReturnFalse() {

        Book book = new Book("title");
        Copy copy = new Copy("rfid", CopyFormat.HARDCOVER, "location", book);
        LocalDate loanDate = LocalDate.now();

        Loan loan = new Loan(copy, loanDate, "Mr. Robot");

        Assert.assertFalse("Si l'emprunt n'est pas revenu, isReturned doit renvoyer faux.", loan.isReturned());
    }

    /**
     * Si l'emprunt est revenu, isReturned doit renvoyer vrai.
     */
    @Test
    public void isReturned_returned_shouldReturnTrue() {

        Book book = new Book("title");
        Copy copy = new Copy("rfid", CopyFormat.HARDCOVER, "location", book);
        LocalDate loanDate = LocalDate.now();

        Loan loan = new Loan(copy, loanDate, "Mr. Robot");
        loan.returnCopy();

        Assert.assertTrue("Si l'emprunt est revenu, isReturned doit renvoyer vrai.", loan.isReturned());
    }


    /**
     * La méthode getDueDate doit renvoyer la LocalDate d'emprunt plus 30 jours.
     */
    @Test
    public void getDueDate_shouldReturnLoanDatePlus30Days() {

        LocalDate loanDate = LocalDate.now();
        LocalDate dueDate = loanDate.plusDays(30);

        Book book = new Book("title");
        Copy copy = new Copy("rfid", CopyFormat.HARDCOVER, "location", book);
        LocalDate dueDateExpected;
        Loan loan;

        dueDateExpected = dueDate;

        loan = new Loan(copy, loanDate, "Mr. Robot");

        Assert.assertEquals("La méthode getDueDate doit renvoyer la LocalDate d'emprunt plus 30 jours.",
                dueDateExpected, loan.getDueDate());


        loanDate = loanDate.plusMonths(-12);
        dueDate = loanDate.plusDays(30);
        dueDateExpected = dueDate;

        loan = new Loan(copy, loanDate, "Mr. Robot");

        Assert.assertEquals("La méthode getDueDate doit renvoyer la LocalDate d'emprunt plus 30 jours.",
                dueDateExpected, loan.getDueDate());
    }

    /**
     * Si l'emprunt vient d'être fait, il ne devrait pas être en retard.
     */
    @Test
    public void isOverdue_notReturnedNotOverdue_shouldReturnFalse() {

        Book book = new Book("title");
        Copy copy = new Copy("rfid", CopyFormat.HARDCOVER, "location", book);
        LocalDate loanDate = LocalDate.now();

        Loan loan = new Loan(copy, loanDate, "Mr. Robot");

        Assert.assertFalse("Un emprunt qui vient d'être fait ne devrait pas être en retard.", loan.isOverdue());
    }

    /**
     * Si l'emprunt a été fait il y a plus de 30 jours et qu'il n'est pas revenu, il
     * devrait être en retard.
     */
    @Test
    public void isOverdue_notReturnedOverdue_shouldReturnTrue() {

        LocalDate loanDate = LocalDate.now().plusDays(-31);

        Book book = new Book("title");
        Copy copy = new Copy("rfid", CopyFormat.HARDCOVER, "location", book);

        Loan loan = new Loan(copy, loanDate, "Mr. Robot");

        Assert.assertTrue("Un emprunt fait il y plus 30 jours et qui n'est pas revenu, devrait être en retard.",
                loan.isOverdue());
    }

    /**
     * Si l'emprunt est revenu dans les 30 jours, il devrait être en retard.
     */
    @Test
    public void isOverdue_returnedWithin30Days_shouldReturnFalse() {

        LocalDate loanDate = LocalDate.now().plusDays(-40);
        LocalDate returnDate = LocalDate.now().plusDays(-20);

        Book book = new Book("title");
        Copy copy = new Copy("rfid", CopyFormat.HARDCOVER, "location", book);

        Loan loan = new Loan(copy, loanDate, "Mr. Robot");
        loan.returnCopy(returnDate);

        Assert.assertFalse(
                "Un emprunt fait il y plus 30 jours et qui est revenu dans les temps, ne devrait pas être en retard.",
                loan.isOverdue());
    }

    /**
     * Si l'emprunt est revenu, mais pas dans les 30 jours, il devrait être en
     * retard.
     */
    @Test
    public void isOverdue_returnedButNotWithin30Days_shouldReturnTrue() {

        LocalDate loanDate = LocalDate.now().plusDays(-40);
        LocalDate returnDate = LocalDate.now().plusDays(-5);

        Book book = new Book("title");
        Copy copy = new Copy("rfid", CopyFormat.HARDCOVER, "location", book);

        Loan loan = new Loan(copy, loanDate, "Mr. Robot");
        loan.returnCopy(returnDate);

        Assert.assertTrue("Un emprunt qui est revenu mais pas dans les 30 jours, devrait être en retard.",
                loan.isOverdue());
    }

}
