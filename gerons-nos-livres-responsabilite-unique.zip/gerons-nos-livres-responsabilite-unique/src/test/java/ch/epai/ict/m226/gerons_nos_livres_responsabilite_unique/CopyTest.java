package ch.epai.ict.m226.gerons_nos_livres_responsabilite_unique;

import org.junit.*;

public class CopyTest {

    /**
     * La classe Copy doit avoir un constructeur avec 4 paramètres.
     */
    @Test
    public void constructor1_shouldCreateInstance() {
        Copy a = new Copy("rfid", CopyFormat.HARDCOVER, "location", new Book("title"));
        Assert.assertNotNull(a);
    }

    /**
     * L'accesseur doit renvoyer la valeur de l'attribut correspondant. Après
     * l'instanciation, la valeur de l'attribut doit être celle du paramètre passée
     * au constructeur ou une chaîne vide si cette valeur est null.
     */
    @Test
    public void getRfid_instanciateNewObject_shouldReturnValueOrEmptyStringIfNull() {

        Copy c;
        String expected;
        String actual;

        expected = "rfid1";
        c = new Copy(expected, CopyFormat.HARDCOVER, "location", new Book("title"));
        actual = c.getRfid();
        Assert.assertEquals("L'accesseur doit renvoyer la valeur passée au constructeur1.", expected, actual);

        expected = "";
        c = new Copy(null, CopyFormat.HARDCOVER, "location", new Book("title"));
        actual = c.getRfid();
        Assert.assertEquals("L'accesseur doit renvoyer une chaîne vide si la valeur passée au constructeur1 est null.",
                expected, actual);

    }

    @Test
    /**
     * Le mutateur doit modifier la valeur de l'attribut correspondant. Si la valeur
     * du paramètre est null, la valeur de l'attribut title doit être une chaîne
     * vide.
     */
    public void setRfid_setNewValue_shouldReturnNewValueOrEmptyStringIfNull() {

        Copy c = new Copy("rfid", CopyFormat.HARDCOVER, "location", new Book("title"));

        String expected;
        String actual;

        expected = "rfid1";
        c.setRfid(expected);
        actual = c.getRfid();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

        expected = "rfid2";
        c.setRfid(expected);
        actual = c.getRfid();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

        expected = "";
        c.setRfid(null);
        actual = c.getRfid();
        Assert.assertEquals(
                "Si la valeur du paramètre du mutateur est null, la valeur de l'attribut doit être une chaîne vide.",
                expected, actual);

    }

    /**
     * L'accesseur doit renvoyer la valeur de l'attribut correspondant. Après
     * l'instanciation, la valeur de l'attribut doit être celle du paramètre passée
     * au constructeur ou une chaîne vide si cette valeur est null.
     */
    @Test
    public void getFormat_instanciateNewObject_shouldReturnValue() {

        Copy c;
        CopyFormat expected;
        CopyFormat actual;

        expected = CopyFormat.PDF;
        c = new Copy("rfid", expected, "location", new Book("title"));
        actual = c.getFormat();
        Assert.assertEquals("L'accesseur doit renvoyer la valeur passée au constructeur1.", expected, actual);
   }

    @Test
    /**
     * Le mutateur doit modifier la valeur de l'attribut correspondant. Si la valeur
     * du paramètre est null, la valeur de l'attribut title doit être une chaîne
     * vide.
     */
    public void setFormat_setNewValue_shouldReturnNewValue() {

        Copy c = new Copy("rfid", CopyFormat.HARDCOVER, "location", new Book("title"));

        CopyFormat expected;
        CopyFormat actual;

        expected = CopyFormat.PAPERBACK;
        c.setFormat(expected);
        actual = c.getFormat();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

        expected = CopyFormat.PDF;
        c.setFormat(expected);
        actual = c.getFormat();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);
    }

    /**
     * L'accesseur doit renvoyer la valeur de l'attribut correspondant. Après
     * l'instanciation, la valeur de l'attribut doit être celle du paramètre passée
     * au constructeur ou une chaîne vide si cette valeur est null.
     */
    @Test
    public void getLocation_instanciateNewObject_shouldReturnValueOrEmptyStringIfNull() {

        Copy c;
        String expected;
        String actual;

        expected = "localtion1";
        c = new Copy("rfid", CopyFormat.HARDCOVER, expected, new Book("title"));
        actual = c.getLocation();
        Assert.assertEquals("L'accesseur doit renvoyer la valeur passée au constructeur1.", expected, actual);

        expected = "";
        c = new Copy(null, CopyFormat.HARDCOVER, null, new Book("title"));
        actual = c.getLocation();
        Assert.assertEquals("L'accesseur doit renvoyer une chaîne vide si la valeur passée au constructeur1 est null.",
                expected, actual);

    }

    @Test
    /**
     * Le mutateur doit modifier la valeur de l'attribut correspondant. Si la valeur
     * du paramètre est null, la valeur de l'attribut title doit être une chaîne
     * vide.
     */
    public void setLocation_setNewValue_shouldReturnNewValueOrEmptyStringIfNull() {

        Copy c = new Copy("rfid", CopyFormat.HARDCOVER, "location", new Book("title"));

        String expected;
        String actual;

        expected = "location1";
        c.setLocation(expected);
        actual = c.getLocation();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

        expected = "location2";
        c.setLocation(expected);
        actual = c.getLocation();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

        expected = "";
        c.setLocation(null);
        actual = c.getLocation();
        Assert.assertEquals(
                "Si la valeur du paramètre du mutateur est null, la valeur de l'attribut doit être une chaîne vide.",
                expected, actual);

    }

    @Test
    /**
     * Le mutateur doit modifier la valeur de l'attribut correspondant. Si la valeur
     * du paramètre est null, la valeur de l'attribut title doit être une chaîne
     * vide.
     */
    public void setBook_setNewValue_shouldReturnNewValue() {

        Copy c = new Copy("rfid", CopyFormat.HARDCOVER, "location", new Book("title"));

        Book expected;
        Book actual;

        expected = new Book("title1");
        c.setBook(expected);
        actual = c.getBook();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

        expected = new Book("title2");
        c.setBook(expected);
        actual = c.getBook();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);
    }
}
