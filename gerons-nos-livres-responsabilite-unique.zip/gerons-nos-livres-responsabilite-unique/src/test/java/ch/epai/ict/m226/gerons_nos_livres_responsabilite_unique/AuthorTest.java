package ch.epai.ict.m226.gerons_nos_livres_responsabilite_unique;

import org.junit.*;

public class AuthorTest {

    /**
     * La classe Book doit avoir un constructeur avec la signature Author(String
     * lastname). La valeur du paramètre doit être affectée à l'attribut lastname.
     * Si la valeur du paramètre est null, la valeur de l'attribut lastname doit
     * être une chaîne vide.
     */
    @Test
    public void constructor_setFirstname_shouldCreateInstance() {
        Author a = new Author("lastname");
        Assert.assertNotNull(a);
    }

    /**
     * La classe Book doit avoir un constructeur avec la signature Book(String
     * lastname, String firtname). La valeur de chaque paramètre doit être affectée
     * à l'attribut correspondant. Si la valeur du paramètre est null, la valeur de
     * l'attribut doit être une chaîne vide.
     */
    @Test
    public void constructor_setFirstnameAndLastname_shouldCreateInstance() {
        Author a = new Author("lastname", "firstname");
        Assert.assertNotNull(a);
    }

    /**
     * L'accesseur doit renvoyer la valeur de l'attribut correspondant.
     */
    @Test
    public void getLastname_instanciateNewObject_returnLastnameOrEmptyStringIfNull() {

        Author a;
        String expected;
        String actual;

        expected = "lastname1";
        a = new Author(expected);
        actual = a.getLastname();
        Assert.assertEquals(
                "L'accesseur getLastname doit renvoyer la valeur passée au constructeur Author(String lastname).",
                expected, actual);

        expected = "";
        a = new Author(null);
        actual = a.getLastname();
        Assert.assertEquals(
                "L'accesseur getLastname doit renvoyer une chaîne vide si la valeur passée au constructeur est null.",
                expected, actual);

        expected = "lastname2";
        a = new Author(expected, "");
        actual = a.getLastname();
        Assert.assertEquals(
                "L'accesseur getLastname doit renvoyer la valeur passée au constructeur Author(String lastname, String firstname).",
                expected, actual);

        expected = "";
        a = new Author(null, "");
        actual = a.getLastname();
        Assert.assertEquals(
                "L'accesseur getLastname doit renvoyer une chaîne vide si la valeur passée au constructeur est null.",
                expected, actual);
    }

    @Test
    /**
     * Le mutateur doit modifier la valeur de l'attribut correspondant. Si la valeur
     * du paramètre est null, la valeur de l'attribut doit être une chaîne vide.
     */
    public void setLastname_setNewValue_shouldReturnNewValueOrEmptyStringIfNull() {

        Author a = new Author("");

        String expected;
        String actual;

        expected = "lastname1";
        a.setLastname(expected);
        actual = a.getLastname();
        Assert.assertEquals("Le mutateur setLastname doit modifier la valeur de l'attribut lastname.", expected,
                actual);

        expected = "lastname2";
        a.setLastname(expected);
        actual = a.getLastname();
        Assert.assertEquals("Le mutateur setLastname doit modifier la valeur de l'attribut lastname.", expected,
                actual);

        expected = "";
        a.setLastname(null);
        actual = a.getLastname();
        Assert.assertEquals(
                "Le mutateur setLastname doit affecter une chaîne vide Ã  l'attribut lastname si la valeur du paramÃ¨tre est null.",
                expected, actual);
    }

    /**
     * L'accesseur doit renvoyer la valeur de l'attribut correspondant.
     */
    @Test
    public void getFirstname_instanciateNewObject_shouldReturnFirstnameOrEmptyStringIfNull() {

        Author a;
        String expected;
        String actual;

        expected = "";
        a = new Author("lastname");
        actual = a.getFirstname();
        Assert.assertEquals(
                "L'accesseur getFirstname doit renvoyer une chaîne vide avec le constructeur Author(String)", expected,
                actual);

        expected = "firstname";
        a = new Author("lastname", expected);
        actual = a.getFirstname();
        Assert.assertEquals(
                "L'accesseur getFirstname doit renvoyer la valeur passée au constructeur Author(String lastname, String firstname).",
                expected, actual);

        expected = "";
        a = new Author("lastname", null);
        actual = a.getFirstname();
        Assert.assertEquals(
                "L'accesseur getFirstname doit renvoyer une chaîne vide si la valeur passée au constructeur est null.",
                expected, actual);
    }

    @Test
    /**
     * Le mutateur doit modifier la valeur de l'attribut correspondant. Si la valeur
     * du paramètre est null, la valeur de l'attribut doit être une chaîne vide.
     */
    public void setFirstname_setNewValue_shouldReturnNewValueOrEmptyStringIfNull() {

        Author a = new Author("");

        String expected;
        String actual;

        expected = "firstname1";
        a.setFirstname(expected);
        actual = a.getFirstname();
        Assert.assertEquals("Le mutateur setFirstname doit modifier la valeur de l'attribut fistname.", expected,
                actual);

        expected = "firstname2";
        a.setFirstname(expected);
        actual = a.getFirstname();
        Assert.assertEquals("Le mutateur setFirstname doit modifier la valeur de l'attribut firstname.", expected,
                actual);

        expected = "";
        a.setLastname(null);
        actual = a.getLastname();
        Assert.assertEquals(
                "Le mutateur setFirstname doit affecter une chaîne vide Ã  l'attribut lastname si la valeur du paramÃ¨tre est null.",
                expected, actual);
    }

    @Test
    /**
     * Si l'attribut firstname est une chaîne vide, la méthode doit renvoyer la
     * valeur de l'attribut lastname.
     */
    public void getFullName_lastnameOnly_shouldReturnLastname() {

        Author a = new Author("lastname1");

        String expected;
        String actual;

        expected = "lastname1";
        actual = a.getFullName();
        Assert.assertEquals(
                "Si l'attribut firstname est une chaîne vide, la mÃ©thode getFullName doit renvoyer la valeur de l'attribut lastname.",
                expected, actual);

        expected = "lastname2";
        a.setLastname(expected);
        actual = a.getFullName();
        Assert.assertEquals("Le mutateur setFirstname doit modifier la valeur de l'attribut firstname.", expected,
                actual);
    }

    @Test
    /**
     * Si l'attribut lastname est une chaîne vide, la méthode doit renvoyer la
     * valeur de l'attribut firstname.
     */
    public void getFullName_firstnameOnly_shouldReturnFirstname() {

        Author a = new Author("");

        String expected;
        String actual;

        expected = "firstname1";
        a.setFirstname(expected);
        actual = a.getFullName();
        Assert.assertEquals(
                "Si l'attribut lastname est une chaîne vide, la mÃ©thode getFullName doit renvoyer la valeur de l'attribut firstname.",
                expected, actual);

        expected = "firstname2";
        a.setFirstname(expected);
        actual = a.getFullName();
        Assert.assertEquals(
                "Si l'attribut lastname est une chaîne vide, la mÃ©thode getFullName doit renvoyer la valeur de l'attribut firstname.",
                expected, actual);
    }

    @Test
    /**
     * Si l'attribut firstname et l'attribut lastname ont une valeur, la méthode
     * doit renvoyer une chaîne composée de l'initiale du prénom suivies d'une
     * espace et du noms.
     */
    public void getFullName_lastnameAndFirstname_shouldReturnFirstnameSpaceLastname() {

        Author a = new Author("lastname", "firstname");

        String expected = "f. lastname";
        String actual = a.getFullName();

        Assert.assertEquals(
                "Si l'attribut firstname et l'attribut lastname ont une valeur, la mÃ©thodegetFullName doit renvoyer une chaîne composÃ©e du nom suivi d'une virgule etde l'initiale du prÃ©nom.",
                expected, actual);
    }
}
