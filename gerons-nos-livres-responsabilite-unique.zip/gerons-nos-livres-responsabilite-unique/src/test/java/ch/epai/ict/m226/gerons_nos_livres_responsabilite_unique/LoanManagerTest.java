package ch.epai.ict.m226.gerons_nos_livres_responsabilite_unique;

import org.junit.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class LoanManagerTest {

    /**
     * La classe LoanManger doit avoir un constructeur avec la signature
     * LoanManager().
     */
    @Test
    public void constructor_shouldCreateInstance() {
        LoanManager loanManager = new LoanManager();
        Assert.assertNotNull("L'objet loanManager doit être instancié.", loanManager);
    }

    /**
     * loanCopy doit ajouter une entrée dans la liste de prêts à la date courente.
     */
    @Test
    public void loanCopy_shouldAddLoanAtCurrentDate() {

        Book book = new Book("title");
        Copy copy = new Copy("rfid", CopyFormat.HARDCOVER, "location", book);
        String borrower = "Mr. Robot";

        Loan loanExpected = new Loan(copy, LocalDate.now(), borrower);
        int loanSizeExpected = 0;
        LoanManager loanManager = new LoanManager();

        Assert.assertEquals(loanSizeExpected, loanManager.getLoans().size());

        loanManager.loanCopy(copy, borrower);

        loanSizeExpected = 1;
        Assert.assertEquals(loanSizeExpected, loanManager.getLoans().size());

        Assert.assertEquals(loanExpected.getCopy(), loanManager.getLoans().get(0).getCopy());
        Assert.assertEquals(loanExpected.getBorrowerName(), loanManager.getLoans().get(0).getBorrowerName());
        Assert.assertTrue(loanExpected.getLoanDate().isEqual(loanManager.getLoans().get(0).getLoanDate()));
    }

    /**
     * returnCopy doit ajouter la date de retour de la copy dans
     *  la liste des prêts.
     */
    @Test
    public void returnCopy_shouldAddReturnDateIntoCorrectLoan(){
        Copy copy[] = {
            new Copy("rfid1", CopyFormat.HARDCOVER, "location", new Book("title1")),
            new Copy("rfid2", CopyFormat.HARDCOVER, "location", new Book("title2")),
            new Copy("rfid3", CopyFormat.HARDCOVER, "location", new Book("title3"))};
        String borrower[] = {"Mr. Robot", "Mr. Jones", "Mrs. Raider"};

        LoanManager loanManager = new LoanManager();
        for (int i = 0; i < 3; i = i + 1){
            loanManager.loanCopy(copy[i], borrower[i]);
        }
        loanManager.returnCopy(copy[1]);

        LocalDate dateReturnedCopyExpected = LocalDate.now();
        Assert.assertEquals(dateReturnedCopyExpected, loanManager.getLoans().get(1).getReturnDate(), 100);
        Assert.assertEquals(null, loanManager.getLoans().get(0).getReturnDate());
        Assert.assertEquals(null, loanManager.getLoans().get(2).getReturnDate());
    }
   /**
     * getDueDate doit retourner la date de retour de la copy en prêt.
     */
    @Test
    public void getDueDate_shouldReturnDateOfReturn(){
        Copy copy = new Copy("rfid", CopyFormat.HARDCOVER, "location", new Book("title1"));
        String borrower = "Mr. Robot";

        LocalDate loanDate = LocalDate.now();
        LocalDate dueDateExpected = loanDate.plusDays(30);

        LoanManager loanManager = new LoanManager();
        loanManager.loanCopy(copy, borrower, loanDate);

        Assert.assertEquals(dueDateExpected, loanManager.getDueDate(copy));
    }

    /**
     * isBorrowed doit retourner true si une entrée de la copy n'a
     *  pas de date de retour. Dans tous les autres cas, elle doit
     *  retourner false.
     */
    @Test
    public void isBorrowed_shouldReturnTrueIfBorrowedElseFalse(){
        Copy copy[] = {
            new Copy("rfid1", CopyFormat.HARDCOVER, "location", new Book("title1")),
            new Copy("rfid2", CopyFormat.HARDCOVER, "location", new Book("title2")),
            new Copy("rfid3", CopyFormat.HARDCOVER, "location", new Book("title3"))};
        String borrower[] = {"Mr. Robot", "Mr. Jones", "Mrs. Raider"};

        LoanManager loanManager = new LoanManager();
        for (int i = 0; i < 3; i = i + 1){
            loanManager.loanCopy(copy[i], borrower[i]);
        }
        loanManager.returnCopy(copy[1]);

        //Make a loan
        loanManager.loanCopy(copy[1], borrower[1]);
        loanManager.returnCopy(copy[1]);
        loanManager.loanCopy(copy[1], borrower[0]);

        Assert.assertTrue(loanManager.isBorrowed(copy[1]));

    }

    /**
     * isOverDue doit retourner true si la copy est empruntée et que
     * le délai de 30 jours est passé.
     */
    @Test
    public void isOverdue_shouldReturnTrueIfDateIsOverDueOtherwiseFalse(){
        Copy copy[] = {
            new Copy("rfid1", CopyFormat.HARDCOVER, "location", new Book("title1")),
            new Copy("rfid2", CopyFormat.HARDCOVER, "location", new Book("title2")),
            new Copy("rfid3", CopyFormat.HARDCOVER, "location", new Book("title3"))};
        String borrower[] = {"Mr. Robot", "Mr. Jones", "Mrs. Raider"};

        LocalDate currentDate = LocalDate.now();
        LocalDate cal = currentDate.plusDays(-20);
        LocalDate cal1 = currentDate.plusDays(-40);
        LocalDate dateLoan[] = {
            cal, cal, cal1
        };

        DateTimeFormatter dtf = DateTimeFormatter.ISO_DATE;
        System.out.println(dtf.format(dateLoan[2]));
        System.out.println(currentDate);

        LoanManager loanManager = new LoanManager();
        for (int i = 0; i < 2; i = i + 1){
            loanManager.loanCopy(copy[i], borrower[i], dateLoan[i]);
            loanManager.returnCopy(copy[i], currentDate);
        }

        loanManager.loanCopy(copy[2], borrower[2], dateLoan[2]);

        Assert.assertFalse(loanManager.isOverdue(copy[0]));
        Assert.assertFalse(loanManager.isOverdue(copy[1]));
        Assert.assertTrue(loanManager.isOverdue(copy[2]));
    }
}
