package ch.epai.ict.m226.gerons_nos_livres_responsabilite_unique;

import java.util.ArrayList;
import org.junit.*;

public class BookTest {

    /**
     * La classe Book doit avoir un constructeur avec la signature Book(String
     * title). La valeur du paramètre doit être affectée à l'attribut correspondant.
     */
    @Test
    public void constructor1_shouldCreateInstance() {
        Book a = new Book("title");
        Assert.assertNotNull(a);
    }

    /**
     * La classe Book doit avoir un constructeur avec la signature Book(String
     * title, String isbn).
     */
    @Test
    public void constructor2_shouldCreateInstance() {
        Book a = new Book("title", "isbn");
        Assert.assertNotNull(a);
    }

    /**
     * La classe Book doit avoir un constructeur avec la signature Book(String,
     * String, String, String, int, ArrayList<Author>).
     */
    @Test
    public void constructor3_shouldCreateInstance() {
        Book a = new Book("title", "isbn", "publisher", "year", 0, new ArrayList<Author>());
        Assert.assertNotNull(a);
    }

    /**
     * L'accesseur doit renvoyer la valeur de l'attribut correspondant. Après
     * l'instanciation, la valeur de l'attribut doit être celle du paramètre passée
     * au constructeur ou une chaîne vide si cette valeur est null.
     */
    @Test
    public void getTitle_instanciateNewObject_shouldReturnValueOrEmptyStringIfNull() {

        Book b;
        String expected;
        String actual;

        expected = "title1";
        b = new Book(expected);
        actual = b.getTitle();
        Assert.assertEquals("L'accesseur doit renvoyer la valeur passée au constructeur1.", expected, actual);

        expected = "";
        b = new Book(null);
        actual = b.getTitle();
        Assert.assertEquals("L'accesseur doit renvoyer une chaîne vide si la valeur passée au constructeur1 est null.",
                expected, actual);

        expected = "title1";
        b = new Book(expected, "isbn");
        actual = b.getTitle();
        Assert.assertEquals("L'accesseur doit renvoyer la valeur passée au constructeur2.", expected, actual);
        expected = "";
        b = new Book(null, "isbn");
        actual = b.getTitle();
        Assert.assertEquals("L'accesseur doit renvoyer une chaîne vide si la valeur passée au constructeur2 est null.",
                expected, actual);

        expected = "title1";
        b = new Book(expected, "isbn", "publisher", "year", 0, new ArrayList<Author>());
        actual = b.getTitle();
        Assert.assertEquals("L'accesseur doit renvoyer la valeur passée au constructeur3.", expected, actual);
        expected = "";
        b = new Book(null, "isbn", "publisher", "year", 0, new ArrayList<Author>());
        actual = b.getTitle();
        Assert.assertEquals("L'accesseur doit renvoyer une chaîne vide si la valeur passée au constructeur3 est null.",
                expected, actual);
    }

    @Test
    /**
     * Le mutateur doit modifier la valeur de l'attribut correspondant. Si la valeur
     * du paramètre est null, la valeur de l'attribut title doit être une chaîne
     * vide.
     */
    public void setTitle_setNewValue_shouldReturnNewValue() {

        Book b = new Book("");

        String expected;
        String actual;

        expected = "title1";
        b.setTitle(expected);
        actual = b.getTitle();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

        expected = "title2";
        b.setTitle(expected);
        actual = b.getTitle();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

        expected = "";
        b.setTitle(null);
        actual = b.getTitle();
        Assert.assertEquals(
                "Si la valeur du paramètre du mutateur est null, la valeur de l'attribut doit être une chaîne vide.",
                expected, actual);

    }

    /**
     * L'accesseur doit renvoyer la valeur de l'attribut correspondant. Après
     * l'instanciation, la valeur de l'attribut doit être celle du paramètre passée
     * au constructeur ou une chaîne vide si cette valeur est null.
     */
    @Test
    public void getIsbn_instanciateNewObject_shouldReturnValueOrEmptyStringIfNull() {

        Book b;
        String expected;
        String actual;

        expected = "";
        b = new Book(null);
        actual = b.getIsbn();
        Assert.assertEquals("L'accesseur doit renvoyer une chaîne vide si l'objet est créé avec le constructeur1.",
                expected, actual);

        expected = "isbn";
        b = new Book("title", expected);
        actual = b.getIsbn();
        Assert.assertEquals("L'accesseur doit renvoyer la valeur passée au constructeur2.", expected, actual);
        expected = "";
        b = new Book("title", null);
        actual = b.getIsbn();
        Assert.assertEquals("L'accesseur doit renvoyer une chaîne vide si la valeur passée au constructeur2 est null.",
                expected, actual);

        expected = "isbn";
        b = new Book("title", expected, "publisher", "year", 0, new ArrayList<Author>());
        actual = b.getIsbn();
        Assert.assertEquals("L'accesseur doit renvoyer la valeur passée au constructeur3.", expected, actual);
        expected = "";
        b = new Book("title", null, "publisher", "year", 0, new ArrayList<Author>());
        actual = b.getIsbn();
        Assert.assertEquals("L'accesseur doit renvoyer une chaîne vide si la valeur passée au constructeur3 est null.",
                expected, actual);
    }

    @Test
    /**
     * Le mutateur doit modifier la valeur de l'attribut correspondant. Si la valeur
     * du paramètre est null, la valeur de l'attribut title doit être une chaîne
     * vide.
     */
    public void setIsbn_setNewValue_shouldReturnNewValue() {

        Book b = new Book("");

        String expected;
        String actual;

        expected = "isbn1";
        b.setIsbn(expected);
        actual = b.getIsbn();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

        expected = "isbn2";
        b.setIsbn(expected);
        actual = b.getIsbn();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

        expected = "";
        b.setIsbn(null);
        actual = b.getIsbn();
        Assert.assertEquals(
                "Si la valeur du paramètre du mutateur est null, la valeur de l'attribut doit être une chaîne vide.",
                expected, actual);
    }

    /**
     * L'accesseur doit renvoyer la valeur de l'attribut correspondant. Après
     * l'instanciation, la valeur de l'attribut doit être celle du paramètre passée
     * au constructeur ou une chaîne vide si cette valeur est null.
     */
    @Test
    public void getPublisher_instanciateNewObject_shouldReturnValueOrEmptyStringIfNull() {

        Book b;
        String expected;
        String actual;

        expected = "";
        b = new Book(null);
        actual = b.getPublisher();
        Assert.assertEquals("L'accesseur doit renvoyer une chaîne vide si l'objet est créé avec le constructeur1.",
                expected, actual);

        expected = "";
        b = new Book(null, null);
        actual = b.getPublisher();
        Assert.assertEquals("L'accesseur doit renvoyer une chaîne vide si l'objet est créé avec le constructeur2.",
                expected, actual);

        expected = "publisher";
        b = new Book("title", "isbn", expected, "year", 0, new ArrayList<Author>());
        actual = b.getPublisher();
        Assert.assertEquals("L'accesseur doit renvoyer la valeur passée au constructeur3.", expected, actual);
        expected = "";
        b = new Book("title", "isbn", null, "year", 0, new ArrayList<Author>());
        actual = b.getPublisher();
        Assert.assertEquals("L'accesseur doit renvoyer une chaîne vide si la valeur passée au constructeur3 est null.",
                expected, actual);
    }

    @Test
    /**
     * Le mutateur doit modifier la valeur de l'attribut correspondant. Si la valeur
     * du paramètre est null, la valeur de l'attribut title doit être une chaîne
     * vide.
     */
    public void setPublisher_setNewValue_shouldReturnNewValue() {

        Book b = new Book("");

        String expected;
        String actual;

        expected = "publisher1";
        b.setPublisher(expected);
        actual = b.getPublisher();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

        expected = "publisher2";
        b.setPublisher(expected);
        actual = b.getPublisher();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

        expected = "";
        b.setPublisher(null);
        actual = b.getPublisher();
        Assert.assertEquals(
                "Si la valeur du paramètre du mutateur est null, la valeur de l'attribut doit être une chaîne vide.",
                expected, actual);
    }

    /**
     * L'accesseur doit renvoyer la valeur de l'attribut correspondant. Après
     * l'instanciation, la valeur de l'attribut doit être celle du paramètre passée
     * au constructeur ou une chaîne vide si cette valeur est null.
     */
    @Test
    public void getYear_instanciateNewObject_shouldReturnValueOrEmptyStringIfNull() {

        Book b;
        String expected;
        String actual;

        expected = "";
        b = new Book(null);
        actual = b.getYear();
        Assert.assertEquals("L'accesseur doit renvoyer une chaîne vide si l'objet est créé avec le constructeur1.",
                expected, actual);

        expected = "";
        b = new Book(null, null);
        actual = b.getYear();
        Assert.assertEquals("L'accesseur doit renvoyer une chaîne vide si l'objet est créé avec le constructeur2.",
                expected, actual);

        expected = "year";
        b = new Book("title", "isbn", "publisher", expected, 0, new ArrayList<Author>());
        actual = b.getYear();
        Assert.assertEquals("L'accesseur doit renvoyer la valeur passée au constructeur3.", expected, actual);
        expected = "";
        b = new Book("title", "isbn", "publisher", null, 0, new ArrayList<Author>());
        actual = b.getYear();
        Assert.assertEquals("L'accesseur doit renvoyer une chaîne vide si la valeur passée au constructeur3 est null.",
                expected, actual);
    }

    @Test
    /**
     * Le mutateur doit modifier la valeur de l'attribut correspondant. Si la valeur
     * du paramètre est null, la valeur de l'attribut title doit être une chaîne
     * vide.
     */
    public void setYear_setNewValue_shouldReturnNewValue() {

        Book b = new Book("");

        String expected;
        String actual;

        expected = "year1";
        b.setYear(expected);
        actual = b.getYear();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

        expected = "year2";
        b.setYear(expected);
        actual = b.getYear();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

        expected = "";
        b.setYear(null);
        actual = b.getYear();
        Assert.assertEquals(
                "Si la valeur du paramètre du mutateur est null, la valeur de l'attribut doit être une chaîne vide.",
                expected, actual);
    }

    /**
     * L'accesseur doit renvoyer la valeur de l'attribut correspondant. Après
     * l'instanciation, la valeur de l'attribut doit être celle du paramètre passée
     * au constructeur.
     */
    @Test
    public void getNumOfPages_instanciateNewObject_shouldReturnValue() {

        Book b;
        int expected;
        int actual;

        expected = 0;
        b = new Book(null);
        actual = b.getNumOfPages();
        Assert.assertEquals("L'accesseur doit renvoyer 0 si l'objet est créé avec le constructeur1.", expected, actual);

        expected = 0;
        b = new Book(null, null);
        actual = b.getNumOfPages();
        Assert.assertEquals("L'accesseur doit renvoyer 0 si l'objet est créé avec le constructeur2.", expected, actual);

        expected = 100;
        b = new Book("title", "isbn", "publisher", "year", expected, new ArrayList<Author>());
        actual = b.getNumOfPages();
        Assert.assertEquals("L'accesseur doit renvoyer la valeur passée au constructeur3.", expected, actual);
    }

    @Test
    /**
     * Le mutateur doit modifier la valeur de l'attribut correspondant.
     */
    public void setNumOfPages_setNewValue_shouldReturnNewValue() {

        Book b = new Book("");

        int expected;
        int actual;

        expected = 10;
        b.setNumOfPages(expected);
        actual = b.getNumOfPages();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

        expected = 20;
        b.setNumOfPages(expected);
        actual = b.getNumOfPages();
        Assert.assertEquals("Le mutateur doit modifier la valeur de l'attribut.", expected, actual);

    }

    @Test
    /**
     * L'accesseur getAuthors doit renvoyer un objet de type ArrayList<Author>. S'il
     * n'y a pas d'auteurs, la liste doit être instanciée mais vide.
     */
    public void getAuthors_instanciateNewBookObject_shouldReturnEmptyList() {

        Book b = new Book("title");

        int expected = 0;

        ArrayList<Author> list = b.getAuthors();
        Assert.assertNotNull("L'attribut authors ne doit pas être null.", list);

        int actual = list.size();
        Assert.assertEquals("Après l'instanciation, la taille de la liste doit être 0.", expected, actual);
    }

}
