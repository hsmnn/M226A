package ch.epai.ict.m226.gerons_nos_livres_responsabilite_unique;

import java.util.ArrayList;

public class Book {

    private String title;
    private String isbn;
    private String publisher;
    private String year;
    private int numOfPages;
    private ArrayList<Author> authors;

    public Book(final String title) {
        this(title, "", "", "", 0, null);
    }

    public Book(final String title, final String isbn) {
        this(title, isbn, "", "", 0, null);
    }

    public Book(final String title, final String isbn, final String publisher, final String year, final int numOfPages,
            final ArrayList<Author> authors) {
        setTitle(title);
        setIsbn(isbn);
        setPublisher(publisher);
        setYear(year);
        setNumOfPages(numOfPages);
        setAuthors(authors);
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        if (title != null) {
            this.title = title;
        } else {
            this.title = "";
        }
    }

    public String getIsbn() {
        return this.isbn;
    }

    public void setIsbn(String isbn) {
        if (isbn != null) {
            this.isbn = isbn;
        } else {
            this.isbn = "";
        }
    }

    public String getPublisher() {
        return this.publisher;
    }

    public void setPublisher(String publisher) {
        if (publisher != null) {
            this.publisher = publisher;
        } else {
            this.publisher = "";
        }
    }

    public String getYear() {
        return this.year;
    }

    public void setYear(String year) {
        if (year != null) {
            this.year = year;
        } else {
            this.year = "";
        }
    }

    public int getNumOfPages() {
        return this.numOfPages;
    }

    public void setNumOfPages(int numOfPages) {
        this.numOfPages = numOfPages;
    }

    public ArrayList<Author> getAuthors() {
        return this.authors;
    }

    public void setAuthors(ArrayList<Author> authors) {
        if (authors != null) {
            this.authors = new ArrayList<Author>(authors);
        } else {
            this.authors = new ArrayList<Author>();
        }
    }

    public String getAuthorsNames() {
        String result = "(";
        for (int index = 0; index < this.authors.size(); index = index + 1) {
            if (index > 0) {
                result = result + ", ";
            }
            result = result + this.authors.get(index).getFullName();
        }
        return result;
    }
}
