package ch.epai.ict.m226.gerons_nos_livres_responsabilite_unique;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 * This class represent how a loan is managed
 * 
 * @author Elie Hausmann
 * @version 1.0
 * @since 1.0
 */
public class LoanManager {

    public ArrayList<Loan> getLoans(){
        ArrayList<Loan> getloans = new ArrayList<Loan>();
        Loan date = LocalDate.now();
        getloans.add(date);
        return null;
    }
    
    public void loanCopy(Copy copy, String borrowerName){
        LocalDate date = LocalDate.now();
        Loan loanCopy = new Loan(copy, date, borrowerName);
        getLoans();
    }

    public void loanCopy(Copy copy, String borrowerName, LocalDate date){

    }

    public void returnCopy(Copy copy){

    }

    public void returnCopy(Copy copy, LocalDate date){

    }

    public LocalDate getDueDate(Copy copy){
        return null;
    }

    public boolean isBorrowed(Copy copy){
        return false;
    }

    public boolean isOverdue(Copy copy){
        return false;
    }
}