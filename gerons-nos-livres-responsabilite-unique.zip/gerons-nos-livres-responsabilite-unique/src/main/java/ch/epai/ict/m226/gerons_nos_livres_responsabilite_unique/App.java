package ch.epai.ict.m226.gerons_nos_livres_responsabilite_unique;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
