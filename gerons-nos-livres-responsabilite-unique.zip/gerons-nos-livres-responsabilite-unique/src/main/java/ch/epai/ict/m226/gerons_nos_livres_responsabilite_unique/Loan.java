package ch.epai.ict.m226.gerons_nos_livres_responsabilite_unique;

import java.time.LocalDate;

/**
 * This class represents a loan entry.
 * 
 * History: 1.0 - Initial version of the class.
 * 
 * 
 * @author mauronf@edufr.ch
 * @version 1.0
 * @since 1.0
 */
public class Loan {
    static private int LOAN_DURATION_NUM_DAY = 30;

    private Copy copy;
    private LocalDate loanDate;
    private LocalDate returnDate;
    private String borrowerName;

    /**
     * This constructeur initialise a Loan.
     * 
     * @param copy         if null, the null shall be used.
     * @param date         if null, the current date shall be used.
     * @param borrowerName if null, an empty String shall be used.
     * 
     * @since 1.0
     */

    public Loan(Copy copy, LocalDate loanDate, String borrowerName) {
        if (copy == null) {
            copy = null;
        } else {
            this.copy = copy;
        }
        if (loanDate == null) {
            this.loanDate = LocalDate.now();
        } else {
            this.loanDate = loanDate;
        }
        if (borrowerName == null) {
            borrowerName = "";
        } else {
            this.borrowerName = borrowerName;
        }
        if (returnDate == null) {
            this.returnDate = null;
        } else {
            this.returnDate = returnDate;
        }
    }

    /**
     * Getter for the copy.
     * 
     * @return the loaned copy
     * 
     * @since 1.0
     */

    public Copy getCopy() {
        return copy;
    }

    /**
     * Getter for the loadDate attribute.
     * 
     * @return the date of the loan
     * 
     * @since 1.0
     */

    public LocalDate getLoanDate() {
        return LocalDate.now();
    }

    /**
     * Getter for the returnDate attribute
     * 
     * @return the date of the return or null if the copy isn't returned
     * 
     * @since 1.0
     */

    public LocalDate getReturnDate() {
        if (this.returnDate == null) {
            this.returnDate = null;
        } else {
            this.returnDate = LocalDate.now();
        }
        return this.returnDate;
    }

    /**
     * Getter for the borrowerName attribute
     * 
     * @return the name of the borrower.
     * 
     * @since 1.0
     */

    public String getBorrowerName() {
        if (this.borrowerName == null) {
            this.borrowerName = "";
        } else {
            this.borrowerName = this.borrowerName;
        }
        return this.borrowerName;
    }

    /**
     * This method represents the action of returning the copy.
     * 
     * @since 1.0
     */

    public void returnCopy() {
        this.returnDate = LocalDate.now();
    }

    /**
     * This method represents the action of returning the copy.
     * 
     * @param date if the date is null, the current date shall be used.
     * 
     * @since 1.0
     */

    public void returnCopy(LocalDate date) {
        this.returnDate = date;
    }

    /**
     * Return the dueDate of the loan.
     * 
     * The due date is computed by adding LOAN_DURATION_NUM_DAY number of days to
     * the loan date.
     * 
     * @return the due date of the loan.
     * 
     * @since 1.0
     */

    public LocalDate getDueDate() {
        return this.loanDate.plusDays(LOAN_DURATION_NUM_DAY);
    }

    /**
     * Determine if the loan is overdue.
     * 
     * The loan is overdue is the copy is not yet returned and the current date is
     * greater the due date or, if the copy was returned and the return date is
     * greater than the due date.
     * 
     * @return the due date of the loan.
     * 
     * @since 1.0
     */

    public boolean isOverdue() {
        boolean isOverdue = false;
        LocalDate diff = this.loanDate.plusDays(30);
        LocalDate diff2 = LocalDate.now().plusDays(-30);
        LocalDate diff3 = LocalDate.now().plusDays(-1);

        if (this.loanDate.isAfter(diff3)) {
            return false;
        }
        if (this.loanDate.isBefore(diff2) && this.returnDate == null) {
            return true;
        }
        if (this.returnDate.isAfter(diff)){
            isOverdue = true;
        }
        return isOverdue;
    }

    /**
     * Determine if the copy is returned.
     *
     * @return true if a copy is returned, otherwise false
     *
     * @since 1.0
     */

    public boolean isReturned() {
        boolean isReturn = true;
        if (this.loanDate != null) {
            isReturn = false;
        }
        if (this.returnDate != null) {
            isReturn = true;
        }
        return isReturn;
    }
}