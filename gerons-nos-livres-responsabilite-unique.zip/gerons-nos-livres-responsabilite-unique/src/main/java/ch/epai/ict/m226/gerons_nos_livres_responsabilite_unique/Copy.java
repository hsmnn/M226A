package ch.epai.ict.m226.gerons_nos_livres_responsabilite_unique;

public class Copy {
    private String rfid;
    private CopyFormat format;
    private String location;
    private Book book;

    public Copy(String rfid, CopyFormat format, String location, Book book) {
        setRfid(rfid);
        setFormat(format);
        setLocation(location);
        setBook(book);
    }

    public String getRfid() {
        return this.rfid;
    }

    public void setRfid(String rfid) {
        if (rfid != null) {
            this.rfid = rfid;
        } else {
            this.rfid = "";
        }
    }

    public CopyFormat getFormat() {
        return this.format;
    }

    public void setFormat(CopyFormat format) {
        this.format = format;
    }

    public String getLocation() {
        return this.location;
    }

    public void setLocation(String location) {
        if (location != null) {
            this.location = location;
        } else {
            this.location = "";
        }
    }

    public Book getBook() {
        return this.book;
    }

    public void setBook(Book book) {
        this.book = book;
    }
}
