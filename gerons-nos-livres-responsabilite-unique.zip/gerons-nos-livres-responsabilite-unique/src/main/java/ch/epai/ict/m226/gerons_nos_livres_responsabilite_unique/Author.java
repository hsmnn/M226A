package ch.epai.ict.m226.gerons_nos_livres_responsabilite_unique;

public class Author {

    private String lastname;
    private String firstname;

    public Author(final String lastname) {
        this(lastname, "");
    }

    public Author(final String lastname, final String firstname) {
        setLastname(lastname);
        setFirstname(firstname);
    }

    public String getLastname() {
        return this.lastname;
    }

    public void setLastname(final String lastname) {
        if (lastname != null) {
            this.lastname = lastname;
        } else {
            this.lastname = "";
        }
    }

    public String getFirstname() {
        return this.firstname;
    }

    public void setFirstname(final String firstname) {
        if (firstname != null) {
            this.firstname = firstname;
        } else {
            this.firstname = "";
        }
    }

    public String getFullName() {
        String data = "";
        if (this.firstname == "") {
            data = this.lastname;
        } else if (this.lastname == "") {
            data = this.firstname;
        } else {
            data = this.firstname.charAt(0) + ". " + this.lastname;
        }
        return data;
    }
}
