package ch.epai.ict.m226.gerons_nos_livres_responsabilite_unique;

public enum CopyFormat {
    PAPERBACK,
    HARDCOVER,
    PDF
}
