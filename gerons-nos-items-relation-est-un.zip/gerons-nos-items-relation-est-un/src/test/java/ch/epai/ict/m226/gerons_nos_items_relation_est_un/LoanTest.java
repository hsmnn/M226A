package ch.epai.ict.m226.gerons_nos_items_relation_est_un;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.Test;

public class LoanTest {

    /**
     * La classe Loan doit avoir un constructeur avec la signature Loan(Copy copy,
     * LocalDate loanDate, String borrower).
     */
    @Test
    public void constructor_shouldCreateInstance() {

        // Test case with all null parameters
        Copy copyExpected = null;
        LocalDate loanDateExpected = LocalDate.now();
        LocalDate returnDateExpected = null;
        String borrowerExpected = "";

        Loan loan = new Loan(null, null, null);
        Assert.assertNotNull(loan);
        Assert.assertEquals(copyExpected, loan.getCopy());
        Assert.assertEquals(loanDateExpected, loan.getLoanDate());
        Assert.assertEquals(returnDateExpected, loan.getReturnDate());
        Assert.assertEquals(borrowerExpected, loan.getBorrowerName());

        // Test case with not null parameters
        Copy copy = new Copy("id", "location", null);
        copyExpected = copy;
        loanDateExpected = LocalDate.now();
        returnDateExpected = null;
        borrowerExpected = "Mr. Robot";

        loan = new Loan(copy, LocalDate.now(), "Mr. Robot");
        Assert.assertNotNull("L'objet loan ne peut pas être null.", loan);
        Assert.assertEquals("La copy enregistrée doit correspondre à la copy passée en paramètre", copyExpected,
                loan.getCopy());
        Assert.assertEquals("La LocalDate du prêt doit entre iniaitalisée.", loanDateExpected, loan.getLoanDate());
        Assert.assertEquals("La LocalDate de retour doit être null.", returnDateExpected, loan.getReturnDate());
        Assert.assertEquals("L'emprenteur doit être initialisé.", borrowerExpected, loan.getBorrowerName());

    }

    /**
     * La méthode returnCopy doit enregistrer la date de retour de l'exemplaire.
     */
    @Test
    public void returnCopy_shouldStoreReturnDate() {

        Copy copy = new Copy("id", "location", null);
        LocalDate returnDateExpected = null;

        Loan loan = new Loan(copy, LocalDate.now(), "Mr. Robot");

        returnDateExpected = LocalDate.now();

        loan.returnCopy(LocalDate.now());
        returnDateExpected = LocalDate.now();
        Assert.assertEquals("La LocalDate de retour doit être la LocalDate courente", returnDateExpected,
                loan.getReturnDate());

    }

    /**
     * La méthode isReturned doit renvoyer faux si la date de retour est null.
     */
    @Test
    public void isReturned_notReturned_shouldReturnFalse() {

        Copy copy = new Copy("id", "location", null);
        LocalDate loanDate = LocalDate.now();

        Loan loan = new Loan(copy, loanDate, "Mr. Robot");

        Assert.assertFalse("Si l'emprunt n'est pas revenu, isReturned doit renvoyer faux.", loan.isReturned());
    }

    /**
     * La méthode isReturned doit renvoyer vrai si la date de retour n'est pas null.
     */
    @Test
    public void isReturned_returned_shouldReturnTrue() {

        Copy copy = new Copy("id", "location", null);
        LocalDate loanDate = LocalDate.now();

        Loan loan = new Loan(copy, loanDate, "Mr. Robot");
        loan.returnCopy();

        Assert.assertTrue("Si l'emprunt est revenu, isReturned doit renvoyer vrai.", loan.isReturned());
    }

    /**
     * La méthode getDueDate doit renvoyer la date d'emprunt plus 30 jours.
     */
    @Test
    public void getDueDate_shouldReturnLoanDatePlus30Days() {

        LocalDate loanDate = LocalDate.now();
        LocalDate dueDate = loanDate.plusDays(30);

        Copy copy = new Copy("id", "location", null);
        LocalDate dueDateExpected;
        Loan loan;

        dueDateExpected = dueDate;

        loan = new Loan(copy, loanDate, "Mr. Robot");

        Assert.assertEquals("La méthode getDueDate doit renvoyer la LocalDate d'emprunt plus 30 jours.",
                dueDateExpected, loan.getDueDate());

        loanDate = loanDate.plusMonths(-12);
        dueDate = loanDate.plusDays(30);
        dueDateExpected = dueDate;

        loan = new Loan(copy, loanDate, "Mr. Robot");

        Assert.assertEquals("La méthode getDueDate doit renvoyer la LocalDate d'emprunt plus 30 jours.",
                dueDateExpected, loan.getDueDate());
    }

    /**
     * La méthode isOverdue doit renvoyer faux si l'emprunt vient d'être créé.
     */
    @Test
    public void isOverdue_notReturnedNotOverdue_shouldReturnFalse() {

        Copy copy = new Copy("id", "location", null);
        LocalDate loanDate = LocalDate.now();

        Loan loan = new Loan(copy, loanDate, "Mr. Robot");

        Assert.assertFalse("Un emprunt qui vient d'être fait ne devrait pas être en retard.", loan.isOverdue());
    }

    /**
     * La méthode isOverdue doit renvoyer vrai ii l'emprunt a été fait il y a plus
     * de 30 jours et que la date de retour est null.
     */
    @Test
    public void isOverdue_notReturnedOverdue_shouldReturnTrue() {

        LocalDate loanDate = LocalDate.now().plusDays(-31);

        Copy copy = new Copy("id", "location", null);

        Loan loan = new Loan(copy, loanDate, "Mr. Robot");

        Assert.assertTrue("Un emprunt fait il y plus 30 jours et qui n'est pas revenu, devrait être en retard.",
                loan.isOverdue());
    }

    /**
     * La méthode isOverdue doit renvoyer faut si la date retour ne dépasse pas la
     * date d'emprunt plus 30 jours.
     */
    @Test
    public void isOverdue_returnedWithin30Days_shouldReturnFalse() {

        LocalDate loanDate = LocalDate.now().plusDays(-40);
        LocalDate returnDate = LocalDate.now().plusDays(-20);

        Copy copy = new Copy("id", "location", null);

        Loan loan = new Loan(copy, loanDate, "Mr. Robot");
        loan.returnCopy(returnDate);

        Assert.assertFalse(
                "Un emprunt fait il y plus 30 jours et qui est revenu dans les temps, ne devrait pas être en retard.",
                loan.isOverdue());
    }

    /**
     * La méthode isOverdue doit renvoyer vrai si la date de retour dépasse la date
     * d'emprunt de plus 30 jours. retard.
     */
    @Test
    public void isOverdue_returnedButNotWithin30Days_shouldReturnTrue() {

        LocalDate loanDate = LocalDate.now().plusDays(-40);
        LocalDate returnDate = LocalDate.now().plusDays(-5);

        Copy copy = new Copy("id", "location", null);

        Loan loan = new Loan(copy, loanDate, "Mr. Robot");
        loan.returnCopy(returnDate);

        Assert.assertTrue("Un emprunt qui est revenu mais pas dans les 30 jours, devrait être en retard.",
                loan.isOverdue());
    }

}
