package ch.epai.ict.m226.gerons_nos_items_relation_est_un;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.Assert;
import org.junit.Test;

public class LoanManagerTest {

    /**
     * La classe LoanManger doit avoir un constructeur avec la signature
     * LoanManager().
     */
    @Test
    public void constructor_shouldCreateInstance() {
        LoanManager loanManager = new LoanManager();
        Assert.assertNotNull("L'objet loanManager doit être instancié.", loanManager);
    }

    /**
     * loanCopy doit ajouter une entrée dans la liste de prêts à la date courante.
     */
    @Test
    public void loanCopy_shouldAddLoanAtCurrentDate() {

        Copy copy = new Copy("id", "location", null);
        String borrower = "Mr. Robot";

        Loan loanExpected = new Loan(copy, LocalDate.now(), borrower);
        int loanSizeExpected = 0;
        LoanManager loanManager = new LoanManager();

        Assert.assertEquals(loanSizeExpected, loanManager.getLoans().size());

        loanManager.loanCopy(copy, borrower);

        loanSizeExpected = 1;
        Assert.assertEquals(loanSizeExpected, loanManager.getLoans().size());

        Assert.assertEquals(loanExpected.getCopy(), loanManager.getLoans().get(0).getCopy());
        Assert.assertEquals(loanExpected.getBorrowerName(), loanManager.getLoans().get(0).getBorrowerName());
        Assert.assertEquals(loanExpected.getLoanDate(), loanManager.getLoans().get(0).getLoanDate());
    }

    /**
     * returnCopy doit ajouter la date de retour de l'exemplaire dans la liste des
     * prêts.
     */
    @Test
    public void returnCopy_shouldAddReturnDateIntoCorrectLoan() {
        Copy copy[] = { new Copy("id1", "location", null),
                new Copy("id2", "location", null),
                new Copy("id3", "location", null) };
        String borrower[] = { "Mr. Robot", "Mr. Jones", "Mrs. Raider" };

        LoanManager loanManager = new LoanManager();
        for (int i = 0; i < 3; i = i + 1) {
            loanManager.loanCopy(copy[i], borrower[i]);
        }
        loanManager.returnCopy(copy[1]);

        LocalDate dateReturnedCopyExpected = LocalDate.now();
        Assert.assertEquals(dateReturnedCopyExpected, loanManager.getLoans().get(1).getReturnDate());
        Assert.assertEquals(null, loanManager.getLoans().get(0).getReturnDate());
        Assert.assertEquals(null, loanManager.getLoans().get(2).getReturnDate());
    }

    /**
     * getDueDate doit renvoyer la date de retour de l'exemplaire en prêt.
     */
    @Test
    public void getDueDate_shouldReturnDateOfReturn() {
        Copy copy = new Copy("id", "location", null);
        String borrower = "Mr. Robot";

        LocalDate loanDate = LocalDate.now();
        LocalDate dueDateExpected = loanDate.plusDays(30);

        LoanManager loanManager = new LoanManager();
        loanManager.loanCopy(copy, borrower, loanDate);

        Assert.assertEquals(dueDateExpected, loanManager.getDueDate(copy));
    }

    /**
     * isBorrowed doit renvoyer vrai si une entrée de l'exemplaire est en prêt. Dans
     * tous les autres cas, elle doit retourner false.
     */
    @Test
    public void isBorrowed_shouldReturnTrueIfBorrowedElseFalse() {
        Copy copy[] = { new Copy("id1", "location", null),
                new Copy("id2", "location", null),
                new Copy("id3", "location", null) };
        String borrower[] = { "Mr. Robot", "Mr. Jones", "Mrs. Raider" };

        LoanManager loanManager = new LoanManager();
        for (int i = 0; i < 3; i = i + 1) {
            loanManager.loanCopy(copy[i], borrower[i]);
        }
        loanManager.returnCopy(copy[1]);

        // Make a loan
        loanManager.loanCopy(copy[1], borrower[1]);
        loanManager.returnCopy(copy[1]);
        loanManager.loanCopy(copy[1], borrower[0]);

        Assert.assertTrue(loanManager.isBorrowed(copy[1]));

    }

    /**
     * isOverDue doit renvoyer vrai si l'exemplaire est en prêt et que l'échéance
     * est passée.
     */
    @Test
    public void isOverdue_shouldReturnTrueIfDateIsOverDueOtherwiseFalse() {
        Copy copy[] = { new Copy("id1", "location", null),
                new Copy("id2", "location", null),
                new Copy("id3", "location", null) };
        String borrower[] = { "Mr. Robot", "Mr. Jones", "Mrs. Raider" };

        LocalDate currentDate = LocalDate.now();
        LocalDate cal = currentDate.plusDays(-40);
        LocalDate dateLoan[] = { cal, cal, cal };

        DateTimeFormatter dtf = DateTimeFormatter.ISO_DATE;
        System.out.println(dtf.format(dateLoan[2]));
        System.out.println(currentDate);

        LoanManager loanManager = new LoanManager();
        for (int i = 0; i < 2; i = i + 1) {
            loanManager.loanCopy(copy[i], borrower[i], dateLoan[i]);
            loanManager.returnCopy(copy[i], currentDate);
        }

        loanManager.loanCopy(copy[2], borrower[2], dateLoan[2]);

        Assert.assertFalse(loanManager.isOverdue(copy[0]));
        Assert.assertFalse(loanManager.isOverdue(copy[1]));
        Assert.assertTrue(loanManager.isOverdue(copy[2]));
    }
}
