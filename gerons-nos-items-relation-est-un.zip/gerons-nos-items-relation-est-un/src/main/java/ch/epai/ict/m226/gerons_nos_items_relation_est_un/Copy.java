package ch.epai.ict.m226.gerons_nos_items_relation_est_un;

/**
 * Représente un exemplaire d'un livre du catalogue de la bibliothèque.
 */
public class Copy {

    private String id;
    private String location;
    private LibraryItem item;

    /**
     * Constructeur
     *
     * @param id       l'identifiant de l'exemplaire
     * @param location la localisation physique de l'exemplaire
     * @param item    une référence à un livre du catalogue
     */
    public Copy(String id, String location, Book item) {
        this.id = StringUtils.emptyStringIfNull(id);
        this.location = StringUtils.emptyStringIfNull(location);
        this.item = item;
    }

    public Copy(String id, String location, Documentary item) {
        this.id = StringUtils.emptyStringIfNull(id);
        this.location = StringUtils.emptyStringIfNull(location);
        this.item = item;
    }

    public Copy(String id, String location, Periodical item) {
        this.id = StringUtils.emptyStringIfNull(id);
        this.location = StringUtils.emptyStringIfNull(location);
        this.item = item;
    }

    /**
     * Accesseur pour l'identifiant
     *
     * @return l'identifiant
     */
    public String getId() {
        return this.id;
    }

    /**
     * Accesseur pour la localisation de l'exemplaire dans les locaux de la
     * bibliothèque.
     *
     * @return la localisation
     */
    public String getLocation() {
        return this.location;
    }

    public LibraryItem getItem() {
        return this.item;
    }
}
