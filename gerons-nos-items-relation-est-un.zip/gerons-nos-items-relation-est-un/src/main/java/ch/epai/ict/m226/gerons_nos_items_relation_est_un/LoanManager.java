package ch.epai.ict.m226.gerons_nos_items_relation_est_un;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Gère les prêts des exemplaires des livres de la bibliothèque.
 */
public class LoanManager {

    private ArrayList<Loan> loans;

    /**
     * Initialize a new LoanManager object.
     */
    public LoanManager() {
        this.loans = new ArrayList<Loan>();
    }

    /**
     * Renvoie une vue non modifiable de la liste des emprunts.
     */
    public List<Loan> getLoans() {
        return Collections.unmodifiableList(this.loans);
    }

    /**
     * Crée un nouvel emprunt pour l'exemplaire du livre passé en paramètre.
     *
     * @param copy         l'exemplaire du livre
     * @param borrowerName le nom de l'emprunteur
     */
    public void loanCopy(Copy copy, String borrowerName) {
        this.loanCopy(copy, borrowerName, LocalDate.now());
    }

    /**
     * Crée un nouvel emprunt pour l'exemplaire du livre passé en paramètre.
     *
     * @param copy         l'exemplaire du livre
     * @param borrowerName la date d'emprunt
     * @param date         le nom de l'emprunteur
     *
     */
    public void loanCopy(Copy copy, String borrowerName, LocalDate date) {
        Loan l = new Loan(copy, date, borrowerName);
        this.loans.add(l);
    }

    /**
     * Enregistre le retour du livre.
     *
     * @param copy l'exemplaire du livre
     */
    public void returnCopy(Copy copy) {
        returnCopy(copy, null);
    }

    /**
     * Enregistre le retour du livre à une certaine date.
     *
     * @param copy l'exemplaire du livre
     * @param date la date de retour
     */
    public void returnCopy(Copy copy, LocalDate date) {
        Loan l = this.findCurrentLoan(copy);
        if (l != null) {
            l.returnCopy(date);
        }
    }

    /**
     * Renvoie la date d'échéance de l'emprunt pour l'exemplaire passé en paramètre
     * si celui-ci est effectivement en prêt.
     *
     * @return la date d'échéance ou null
     */
    public LocalDate getDueDate(Copy copy) {
        Loan l = this.findCurrentLoan(copy);
        if (l != null) {
            return l.getDueDate();
        }
        return null;
    }

    /**
     * Renvoie vrai si l'exemplaire est actuellement en prêt et que la date
     * d'échéance est dépassée.
     *
     * @return vrai si l'échéance est dépassée
     */
    public boolean isOverdue(Copy copy) {
        Loan l = this.findCurrentLoan(copy);
        if (l != null) {
            return l.isOverdue();
        }
        return false;
    }

    /**
     * Renvoie vrai si l'exemplaire du livre est actuellement en prêt.
     *
     * @return vrai si le livre est en prêt
     */
    public boolean isBorrowed(Copy copy) {
        Loan l = this.findCurrentLoan(copy);
        return l != null;
    }

    /**
     * Recherche le prêt le plus récent qui n'a pas encore été rendu pour
     * l'exemplaire passé en paramètre.
     *
     * @param copy l'exemplaire
     * @return le prêt courant s'il exite, sinon null
     */
    private Loan findCurrentLoan(Copy copy) {
        for (int i = this.loans.size() - 1; i >= 0; i = i - 1) {
            Loan l = this.loans.get(i);
            if (!l.isReturned()) {
                if (l.getCopy().getId().equals(copy.getId())) {
                    return l;
                }
            }
        }
        return null;
    }
}
