package ch.epai.ict.m226.gerons_nos_items_relation_est_un;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Documentary implements LibraryItem {

    private String id;
    private String title;
    private ArrayList<Writer> writer = new ArrayList<Writer>();
    private ArrayList<Director> director = new ArrayList<Director>();
    private LocalDate launchDate;
    private String description;
    private String language;

    public Documentary(String id, String title, ArrayList<Director> directors, ArrayList<Writer> writers,
            LocalDate launchDate, String description, String language) {
        this.id = StringUtils.emptyStringIfNull(id);
        this.title = StringUtils.emptyStringIfNull(title);
        this.description = StringUtils.emptyStringIfNull(description);
        this.language = StringUtils.emptyStringIfNull(language);

        if (directors != null) {
            this.director = new ArrayList<Director>(directors);
        } else {
            this.director = new ArrayList<Director>();
        }
        if (writers != null) {
            this.writer = new ArrayList<Writer>(writers);
        } else {
            this.writer = new ArrayList<Writer>();
        }
        this.launchDate = launchDate;
    }

    @Override
    public String getId() {
        return this.id;
    }

    @Override
    public String getTitle() {
        return this.title;
    }

    @Override
    public String getDescription() {
        return this.description;
    }

    @Override
    public String getLanguage() {
        return this.language;
    }

    @Override
    public String getKindOfItem() {
        return "DOCUMENTARY";
    }

    public String getDirectorsNames(){
        String directorsNames = "";
        char initial = 'a';
        if (this.director.size() >  1){
            for (int i = 0; i < this.director.size(); i += 1){
                if (i + 1 == this.director.size()){
                    directorsNames += this.director.get(i).getFirstName().charAt(0) + ". " + this.director.get(i).getLastName();
                }else{
                    directorsNames += this.director.get(i).getFirstName().charAt(0) + ". " + this.director.get(i).getLastName() +  ", ";
                }
            }
        }
        return directorsNames;
    }

    public String getWritersNames(){
        String writersNames = "";
        char initial = 'a';
        if (this.writer.size() >  1){
            for (int i = 0; i < this.writer.size(); i += 1){
                if (i + 1 == this.writer.size()){
                    writersNames += this.writer.get(i).getFirstName().charAt(0) + ". " + this.writer.get(i).getLastName();
                }else{
                    writersNames += this.writer.get(i).getFirstName().charAt(0) + ". " + this.writer.get(i).getLastName() +  ", ";
                }
            }
        }
        return writersNames;
    }

    public ArrayList<Director> getDirectors(){
        return this.director;
    }

    public ArrayList<Writer> getWriters(){
        return this.writer;
    }

    public String getLaunchDate(){
        if (this.launchDate == null){
            return "";
        }
        return launchDate.format(DateTimeFormatter.BASIC_ISO_DATE);
    }
}