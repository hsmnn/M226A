package ch.epai.ict.m226.gerons_nos_items_relation_est_un;

public interface LibraryItem {
    public String getId();
    public String getTitle();
    public String getDescription();
    public String getLanguage();
    public String getKindOfItem();
}