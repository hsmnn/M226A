package ch.epai.ict.m226.gerons_nos_items_relation_est_un;

import java.time.LocalDate;

/**
 * Représente un emprunt d'un exemplaire livre de la bibliothèque.
 */
public class Loan {
    static private int LOAN_DURATION_NUM_DAY = 30;

    private Copy copy;
    private LocalDate loanDate;
    private LocalDate returnDate;
    private String borrowerName;
    private LocalDate dueDate;

    /**
     * Constructeur
     *
     * @param copy         l'exemplaire du livre
     * @param loanDate     la date d'emprunt
     * @param borrowerName le nom de l'emprunteur
     */
    public Loan(Copy copy, LocalDate loanDate, String borrowerName) {
        this.copy = copy;
        if (loanDate == null) {
            this.loanDate = LocalDate.now();
        } else {
            this.loanDate = loanDate;
        }

        this.dueDate = this.loanDate.plusDays(LOAN_DURATION_NUM_DAY);
        this.borrowerName = StringUtils.emptyStringIfNull(borrowerName);
    }

    /**
     * Accesseur pour l'exemplaire du livre emprunté.
     *
     * @return l'exemplaire du livre
     */
    public Copy getCopy() {
        return this.copy;
    }

    /**
     * Accesseur pour la date d'emprunt
     *
     * @return la date d'emprunt
     */
    public LocalDate getLoanDate() {
        return this.loanDate;
    }

    /**
     * Accesseur pour la date de retour de l'exemplaire du livre
     *
     * @return la date de retour
     */
    public LocalDate getReturnDate() {
        return this.returnDate;
    }

    /**
     * Accesseur pour le nom de l'emprunteur
     *
     * @return le nom de l'emprunteur
     */
    public String getBorrowerName() {
        return this.borrowerName;
    }

    /**
     * Représente l'action de rendre l'exemplaire du livre.
     */
    public void returnCopy() {
        this.returnCopy(null);
    }

    /**
     * Représente l'action de rendre l'exemplaire du livre.
     *
     * @param date la date de retour
     */
    public void returnCopy(LocalDate date) {
        if (date == null) {
            this.returnDate = LocalDate.now();
        } else {
            this.returnDate = date;
        }
    }

    /**
     * Renvoie la date d'échéance de l'emprunt
     *
     * La date d'échéance est calculée en ajoutant LOAN_DURATION_NUM_DAY jours à la
     * date d'emprunt.
     *
     * @return la date d'échéance.
     */
    public LocalDate getDueDate() {
        return this.dueDate;
    }

    /**
     * Détermine si la date d'échéance est dépassée.
     *
     * @return vrai si la date d'échéance est dépassée.
     */
    public boolean isOverdue() {
        LocalDate refDate = this.returnDate;
        if (refDate == null) {
            refDate = LocalDate.now();
        }
        return refDate.isAfter(this.getDueDate());
    }

    /**
     * Determine si l'exemplaire du livre a été rendu.
     *
     * @return vrai si l'exemplaire est rendu.
     */
    public boolean isReturned() {
        return this.returnDate != null;
    }

}
