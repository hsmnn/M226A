package ch.epai.ict.m226.gerons_nos_items_relation_est_un;

/**
 * Représente les différents format que peut avoir un livre.
 */
public enum BookFormat {
    PAPERBACK,
    HARDCOVER,
    PDF
}
