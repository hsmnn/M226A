package ch.epai.ict.m226.gerons_nos_items_relation_est_un;

public class StringUtils {

    public static String emptyStringIfNull(String value) {
        if (value != null) {
            return value;
        }
        return "";
    }
}
